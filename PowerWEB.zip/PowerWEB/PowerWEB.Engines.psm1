﻿# SPDX-License-Identifier: MIT
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'PowerWEB.Audit.psm1')

function Get-PWBrowserRuntime {
    $node=Get-Command node.exe -ErrorAction SilentlyContinue
    $browser=''
    foreach ($candidate in @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Google\Chrome\Application\chrome.exe")) {
        if (Test-Path -LiteralPath $candidate) { $browser=$candidate; break }
    }
    [pscustomobject]@{ NodePath=$(if ($node) {$node.Source} else {''}); BrowserPath=$browser }
}

function Invoke-PWBrowserAudit {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ScopeUrl,[Parameter(Mandatory)][string]$NodePath,[Parameter(Mandatory)][string]$BrowserPath,
        [string[]]$SeedUrls=@(),[string[]]$Exclude=@(),[hashtable]$Headers=@{},
        [ValidateRange(1,50)][int]$MaxPages=10,[ValidateRange(0,10)][int]$MaxDepth=2,
        [ValidateRange(1,60)][int]$TimeoutSeconds=15,[ValidateRange(100,10000)][int]$SettleMs=1000,
        [ValidateRange(1,5000)][int]$MaxRequests=500,[switch]$Xss,[hashtable]$Control)
    if (-not $Control) { $Control=[hashtable]::Synchronized(@{Cancel=$false;Request=$null;Message=''}) }
    foreach ($path in @($NodePath,$BrowserPath)) { if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Program not found: $path" } }
    if (-not (Test-PWScope $ScopeUrl $ScopeUrl $Exclude)) { throw 'Invalid or excluded scope.' }
    $script=Join-Path $PSScriptRoot 'browser\powerweb-browser.mjs'
    $config=@{ ScopeUrl=$ScopeUrl;BrowserPath=$BrowserPath;SeedUrls=$SeedUrls;Exclude=$Exclude;Headers=$Headers;MaxPages=$MaxPages;MaxDepth=$MaxDepth;TimeoutSeconds=$TimeoutSeconds;SettleMs=$SettleMs;MaxRequests=$MaxRequests;Xss=[bool]$Xss }
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName=$NodePath; $start.Arguments='"'+$script+'"'; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardInput=$true; $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.StandardOutputEncoding=[Text.Encoding]::UTF8; $start.StandardErrorEncoding=[Text.Encoding]::UTF8
    $process=[Diagnostics.Process]::new(); $process.StartInfo=$start
    $result=$null; $failure=''; $cancelAt=$null; $started=$false
    try {
        [void]$process.Start(); $started=$true; $stderr=$process.StandardError.ReadToEndAsync()
        $inputBytes=[Text.Encoding]::UTF8.GetBytes(($config | ConvertTo-Json -Depth 5 -Compress)+"`n")
        $process.StandardInput.BaseStream.Write($inputBytes,0,$inputBytes.Length); $process.StandardInput.BaseStream.Flush()
        $line=$process.StandardOutput.ReadLineAsync()
        while ($true) {
            if ($Control.Cancel -and $null -eq $cancelAt) { $cancelAt=[DateTime]::UtcNow; try { $process.StandardInput.WriteLine('{"cancel":true}'); $process.StandardInput.Flush() } catch {} }
            if ($null -ne $cancelAt -and ([DateTime]::UtcNow-$cancelAt).TotalSeconds -gt 35) { throw 'Browser cancellation took too long; please check the browser process.' }
            if ($line.IsCompleted) {
                $text=$line.GetAwaiter().GetResult(); if ($null -eq $text) { break }
                $message=$text | ConvertFrom-Json
                switch ($message.type) { 'progress' {$Control.Message=[string]$message.data} 'result' {$result=$message.data} 'error' {$failure=[string]$message.data} }
                $line=$process.StandardOutput.ReadLineAsync()
            } else { Start-Sleep -Milliseconds 50 }
        }
        $process.WaitForExit()
        if ($failure) { throw $failure }
        if ($process.ExitCode -ne 0 -or $null -eq $result) { throw ('Browser test failed: '+$stderr.GetAwaiter().GetResult()) }
        return $result
    } finally {
        if ($started -and -not $process.HasExited) { $process.Kill() }
        $process.Dispose()
    }
}

Export-ModuleMember -Function Get-PWBrowserRuntime,Invoke-PWBrowserAudit
