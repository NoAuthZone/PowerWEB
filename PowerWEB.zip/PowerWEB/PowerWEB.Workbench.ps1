﻿# SPDX-License-Identifier: MIT
[CmdletBinding()]
param([switch]$NoShow)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
$modulePath=Join-Path $PSScriptRoot 'PowerWEB.Audit.psm1'
Import-Module $modulePath -Force
Import-Module (Join-Path $PSScriptRoot 'PowerWEB.Engines.psm1') -Force
Import-Module (Join-Path $PSScriptRoot 'PowerWEB.Scanner.psm1') -Force
$proxyModulePath=Join-Path $PSScriptRoot 'PowerWEB.Proxy.psm1'
Import-Module $proxyModulePath -Force
[xml]$layout=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PowerWEB.xaml') -Raw -Encoding UTF8
$window=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($layout))
$controls=@{}
$ns=[Xml.XmlNamespaceManager]::new($layout.NameTable); $ns.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')
foreach ($node in $layout.SelectNodes('//*[@x:Name]',$ns)) { $name=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml'); $controls[$name]=$window.FindName($name) }
$controls.Method.ItemsSource=@('GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'); $controls.Method.SelectedIndex=0
$controls.Risk.ItemsSource=@('Info','Low','Medium','High','Critical'); $controls.Risk.SelectedIndex=0
$controls.FindingStatus.ItemsSource=@('Open','Confirmed','False positive','Fixed'); $controls.FindingStatus.SelectedIndex=0
$controls.ChecklistStatus.ItemsSource=@('Open','Reviewed','Finding','Not applicable')
$controls.IntruderMethod.ItemsSource=@('GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'); $controls.IntruderMethod.SelectedIndex=0
$controls.IntruderMode.ItemsSource=@('Sniper','Battering ram','Pitchfork','Cluster bomb'); $controls.IntruderMode.SelectedIndex=0
$controls.DataMethod.ItemsSource=@('GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'); $controls.DataMethod.SelectedIndex=0
$runtime=Get-PWBrowserRuntime; $controls.NodePath.Text=$runtime.NodePath; $controls.BrowserPath.Text=$runtime.BrowserPath
$state=@{ Project=(New-PWProject); Worker=$null; Handle=$null; Control=$null; Kind=''; Response=$null; Baseline=$null; Finding=$null; Dirty=$false; RequestUrl=''; RequestMethod='' }
$state.CurrentSession='A'
$state.Sessions=@{A=@{Headers='';Cookies=[Net.CookieContainer]::new();Origin=''};B=@{Headers='';Cookies=[Net.CookieContainer]::new();Origin=''}}
$controls.SessionChoice.ItemsSource=@('A','B');$controls.SessionChoice.SelectedIndex=0
$timer=[Windows.Threading.DispatcherTimer]::new(); $timer.Interval=[TimeSpan]::FromMilliseconds(150)
$state.Proxy=$null; $state.ProxyPS=$null; $state.ProxyHandle=$null; $state.ProxyCurrent=$null; $state.ProxyHistCount=-1
$proxyTimer=[Windows.Threading.DispatcherTimer]::new(); $proxyTimer.Interval=[TimeSpan]::FromMilliseconds(250)

function Show-Error($ErrorRecord) { $controls.Status.Text='Error: '+$ErrorRecord.Exception.Message }
function Get-Lines([string]$Text) { @($Text -split '\r?\n' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
function Sync-Project {
    [void]$controls.Checklist.CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true)
    [void]$controls.Checklist.CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)
    $state.Project.Name=$controls.ProjectName.Text; $state.Project.ScopeUrl=$controls.Scope.Text.Trim(); $state.Project.Notes=$controls.Notes.Text
    $state.Project.Settings=[pscustomobject]@{ MaxPages=$controls.MaxPages.Text; MaxDepth=$controls.MaxDepth.Text; DelayMs=$controls.Delay.Text; TimeoutSeconds=$controls.Timeout.Text; Active=[bool]$controls.Active.IsChecked; Seeds=@(Get-Lines $controls.Seeds.Text); Excludes=@(Get-Lines $controls.Excludes.Text) }
    $state.Project.Version='3.2.0'
    $state.Project.Settings | Add-Member -NotePropertyName Browser -NotePropertyValue ([pscustomobject]@{NodePath=$controls.NodePath.Text;BrowserPath=$controls.BrowserPath.Text;MaxPages=$controls.BrowserPages.Text;SettleMs=$controls.BrowserSettle.Text;MaxRequests=$controls.BrowserRequests.Text;Xss=[bool]$controls.BrowserXss.IsChecked})
    $ruleSelection=@{};foreach($name in @('NativeSqlError','NativeSqlBool','NativeTemplate','NativeHtml','NativeRedirect','NativeCrlf','NativeCors')){$ruleSelection[$name]=[bool]$controls[$name].IsChecked}
    $state.Project.Settings | Add-Member -NotePropertyName Native -NotePropertyValue ([pscustomobject]@{MaxPages=$controls.NativePages.Text;MaxRequests=$controls.NativeRequests.Text;MaxParameters=$controls.NativeParameters.Text;MaxMinutes=$controls.NativeMinutes.Text;Rules=[pscustomobject]$ruleSelection})
}
function Refresh-Findings {
    $term=$controls.Filter.Text
    $controls.Findings.ItemsSource=@($state.Project.Findings | Where-Object { -not $term -or (($_.Titel+' '+$_.Url+' '+$_.Risiko+' '+$_.Status).IndexOf($term,[StringComparison]::OrdinalIgnoreCase) -ge 0) })
}
function Refresh-Project {
    $controls.ProjectName.Text=$state.Project.Name; $controls.Scope.Text=$state.Project.ScopeUrl; $controls.Notes.Text=$state.Project.Notes
    $s=$state.Project.Settings; $controls.MaxPages.Text=[string]$s.MaxPages; $controls.MaxDepth.Text=[string]$s.MaxDepth; $controls.Delay.Text=[string]$s.DelayMs; $controls.Timeout.Text=[string]$s.TimeoutSeconds
    $controls.Active.IsChecked=[bool]$s.Active; $controls.Seeds.Text=$s.Seeds -join "`r`n"; $controls.Excludes.Text=$s.Excludes -join "`r`n"
    # Missing optional settings in older/new projects must not inherit a previous project.
    foreach($name in @('BrowserPages','BrowserSettle','BrowserRequests','NativePages','NativeRequests','NativeParameters','NativeMinutes')) {
        $node=$layout.SelectSingleNode("//*[@x:Name='$name']",$ns);$controls[$name].Text=$node.GetAttribute('Text')
    }
    foreach($name in @('BrowserXss','NativeSqlError','NativeSqlBool','NativeTemplate','NativeHtml','NativeRedirect','NativeCrlf','NativeCors')) {
        $node=$layout.SelectSingleNode("//*[@x:Name='$name']",$ns);$controls[$name].IsChecked=$node.GetAttribute('IsChecked') -eq 'True'
    }
    $controls.NodePath.Text=$runtime.NodePath;$controls.BrowserPath.Text=$runtime.BrowserPath
    if ($s.PSObject.Properties.Name -contains 'Browser') {
        $controls.NodePath.Text=$s.Browser.NodePath; $controls.BrowserPath.Text=$s.Browser.BrowserPath; $controls.BrowserPages.Text=$s.Browser.MaxPages; $controls.BrowserSettle.Text=$s.Browser.SettleMs; $controls.BrowserRequests.Text=$s.Browser.MaxRequests; $controls.BrowserXss.IsChecked=[bool]$s.Browser.Xss
    }
    if($s.PSObject.Properties.Name -contains 'Native'){
        $controls.NativePages.Text=$s.Native.MaxPages;$controls.NativeRequests.Text=$s.Native.MaxRequests;$controls.NativeParameters.Text=$s.Native.MaxParameters;$controls.NativeMinutes.Text=$s.Native.MaxMinutes
        foreach($prop in $s.Native.Rules.PSObject.Properties){if($prop.Name -in @('NativeSqlError','NativeSqlBool','NativeTemplate','NativeHtml','NativeRedirect','NativeCrlf','NativeCors')){$controls[$prop.Name].IsChecked=[bool]$prop.Value}}
    }
    $controls.Checklist.ItemsSource=@($state.Project.Checklist); $controls.History.ItemsSource=@($state.Project.History); Refresh-Findings
}
function Set-Busy([bool]$Busy) {
    foreach ($name in @('Start','Send','Fuzz','Scope','ProjectName','Notes','Seeds','Excludes','MaxPages','MaxDepth','Delay','Timeout','AuthHeaders','Active','NewProject','LoadProject','SaveProject','Export','RequestUrl','Method','RequestHeaders','RequestBody','AllowWrite','FuzzUrl','Payloads')) { $controls[$name].IsEnabled=-not $Busy }
    $controls.Cancel.IsEnabled=$Busy; $controls.StopFuzz.IsEnabled=$Busy
    foreach ($name in @('BrowserStart','NodePath','BrowserPath','ChooseNode','ChooseBrowser','BrowserPages','BrowserSettle','BrowserRequests','BrowserXss')) { $controls[$name].IsEnabled=-not $Busy }
    $controls.BrowserCancel.IsEnabled=$Busy
    foreach($name in @('NativeStart','NativePages','NativeRequests','NativeParameters','NativeMinutes','NativeAuthorize','NativeSqlError','NativeSqlBool','NativeTemplate','NativeHtml','NativeRedirect','NativeCrlf','NativeCors','SessionChoice','SessionClear','SessionInfo','RoleCompare','RoleUrl')){$controls[$name].IsEnabled=-not $Busy}
    $controls.NativeCancel.IsEnabled=$Busy
    foreach($name in @('IntruderStart','IntruderMethod','IntruderUrl','IntruderFromRequest','IntruderMode','IntruderHeaders','IntruderBody','IntruderSet1','IntruderSet2','IntruderSet3','IntruderSet4','IntruderMax','IntruderEncode','IntruderAuthorize')){$controls[$name].IsEnabled=-not $Busy}
    $controls.IntruderCancel.IsEnabled=$Busy
    foreach($name in @('DataStart','DataMethod','DataUrl','DataFromRequest','DataHeaders','DataBody','DataTable','DataMax','DataEncode','DataAuthorize')){$controls[$name].IsEnabled=-not $Busy}
    $controls.DataCancel.IsEnabled=$Busy
}
function Get-Options {
    Sync-Project
    if (-not (Test-PWScope $state.Project.ScopeUrl $state.Project.ScopeUrl)) { throw 'Please enter a valid target scope.' }
    $pause=0; $timeout=0
    if (-not [int]::TryParse($controls.Delay.Text,[ref]$pause) -or $pause -lt 0 -or $pause -gt 10000) { throw 'Delay must be between 0 and 10000 ms.' }
    if (-not [int]::TryParse($controls.Timeout.Text,[ref]$timeout) -or $timeout -lt 1 -or $timeout -gt 60) { throw 'Timeout must be between 1 and 60 seconds.' }
    $session=$state.Sessions[$state.CurrentSession];$origin=([Uri]$state.Project.ScopeUrl).GetLeftPart([UriPartial]::Authority)
    if($session.Origin -and $session.Origin -ne $origin){throw 'Session belongs to a different host/port. Clear it on tab 8 or pick another session.'}
    $session.Origin=$origin;$session.Headers=$controls.AuthHeaders.Text
    @{ ScopeUrl=$state.Project.ScopeUrl; Headers=(ConvertFrom-PWHeaderText $controls.AuthHeaders.Text); CookieContainer=$session.Cookies; Exclude=@(Get-Lines $controls.Excludes.Text); DelayMs=$pause; TimeoutSeconds=$timeout }
}
function Start-Worker([string]$Kind,[hashtable]$Options) {
    if ($state.Worker) { throw 'A run is already active.' }
    $state.Kind=$Kind; $state.Control=[hashtable]::Synchronized(@{ Cancel=$false; Request=$null; Message='Run starting ...' }); $Options.Control=$state.Control
    if ($Kind -eq 'Request') { $state.RequestUrl=$Options.Url; $state.RequestMethod=$Options.Method }
    $state.Worker=[PowerShell]::Create()
    $code='param($module,$kind,$options) $ErrorActionPreference="Stop"; Import-Module $module -Force; Import-Module (Join-Path (Split-Path $module) "PowerWEB.Engines.psm1") -Force; Import-Module (Join-Path (Split-Path $module) "PowerWEB.Scanner.psm1") -Force; switch($kind) { "Scan" { Invoke-PWAudit @options } "Request" { Invoke-PWHttp @options } "Fuzz" { Invoke-PWFuzz @options } "Browser" { Invoke-PWBrowserAudit @options } "Native" { Invoke-PWNativeScan @options } "Roles" { Invoke-PWRoleComparison @options } "Intruder" { Invoke-PWIntruder @options } "DataTable" { Invoke-PWDataTable @options } }'
    try {
        [void]$state.Worker.AddScript($code).AddArgument($modulePath).AddArgument($Kind).AddArgument($Options)
        $state.Handle=$state.Worker.BeginInvoke(); Set-Busy $true; $timer.Start()
    } catch { $state.Worker.Dispose(); $state.Worker=$null; Set-Busy $false; throw }
}
function Merge-Findings($Items) {
    # O(n) dedup via a key set instead of a per-item Where-Object scan plus an
    # array rebuild per addition. Same match rule: Titel case-insensitive,
    # Url/Nachweis case-sensitive (key mirrors -eq / -ceq / -ceq).
    $incoming=@($Items)
    if (-not $incoming.Count) { return }
    $sep=[char]0
    $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($existing in @($state.Project.Findings)) {
        [void]$seen.Add(([string]$existing.Titel).ToLowerInvariant()+$sep+[string]$existing.Url+$sep+[string]$existing.Nachweis)
    }
    $added=[Collections.Generic.List[object]]::new()
    foreach ($f in $incoming) {
        if ($seen.Add(([string]$f.Titel).ToLowerInvariant()+$sep+[string]$f.Url+$sep+[string]$f.Nachweis)) { $added.Add($f) }
    }
    if ($added.Count) { $state.Project.Findings=@($state.Project.Findings)+$added.ToArray() }
}
function Show-Response($Response) {
    $lines=[Collections.Generic.List[string]]::new()
    $lines.Add(('HTTP {0} | {1} ms to headers | {2} bytes read | Truncated: {3}' -f $Response.Status,$Response.HeaderMs,$Response.BytesRead,$Response.Truncated))
    foreach ($key in ($Response.Headers.Keys | Sort-Object)) {
        $value=if ($key -match '(?i)cookie|authorization|token|secret|key|authenticate') { '[hidden]' } else { $Response.Headers[$key] }
        $lines.Add("${key}: $value")
    }
    if ($Response.Certificate) { $lines.Add('Zertifikat: '+($Response.Certificate | ConvertTo-Json -Compress)) }
    $lines.Add(''); $lines.Add($Response.Body); $controls.Response.Text=$lines -join "`r`n"
}
$timer.Add_Tick({
    if (-not $state.Handle) { return }
    $controls.Status.Text=$state.Control.Message
    if (-not $state.Handle.IsCompleted) { return }
    $timer.Stop()
    try {
        $output=$state.Worker.EndInvoke($state.Handle)
        if ($state.Worker.HadErrors) { throw $state.Worker.Streams.Error[0] }
        if ($output.Count -lt 1) { throw 'Run returned no result.' }
        $result=$output[0]
        switch ($state.Kind) {
            'Native' {
                Merge-Findings $result.Findings;$state.Project.History=@($state.Project.History)+@($result.History);$state.Project.Runs=@($state.Project.Runs)+@($result.Summary);$controls.NativeResults.ItemsSource=@($result.Tests)
                $controls.Status.Text='Native engine: {0}; {1} requests, {2} findings. Control evidence is in the JSON/HTML report.' -f $result.Summary.Status,$result.Summary.Anfragen,@($result.Findings).Count
            }
            'Roles' {
                $state.Project.Runs=@($state.Project.Runs)+@([pscustomobject]@{Typ='Role comparison';ZeitpunktUtc=[DateTime]::UtcNow.ToString('o');Ergebnis=$result})
                $comparisonText=if($result.TextVergleichbar){[string]$result.TextGleich}else{'not comparable'}
                $controls.Status.Text='A/B: HTTP {0}/{1}; text identical: {2}; truncated: {3}. Assess expected permissions manually.' -f $result.StatusA,$result.StatusB,$comparisonText,$result.Gekuerzt
            }
            'Browser' {
                Merge-Findings $result.Findings; $state.Project.History=@($state.Project.History)+@($result.History)
                $result.Summary | Add-Member -NotePropertyName BrowserSeiten -NotePropertyValue @($result.Pages)
                $state.Project.Runs=@($state.Project.Runs)+@($result.Summary); $controls.BrowserResults.ItemsSource=@($result.Pages)
                $controls.Status.Text='Browser: {0}; {1} pages, {2} hints. Details in findings and report.' -f $result.Summary.Status,@($result.Pages).Count,@($result.Findings).Count
            }
            'Scan' {
                Merge-Findings $result.Findings; $state.Project.History=@($state.Project.History)+@($result.History); $state.Project.Runs=@($state.Project.Runs)+@($result.Summary)
                $controls.Status.Text='{0}: {1} pages, {2} requests, {3} errors. {4} URLs still queued. Findings on tab 2.' -f $result.Summary.Status,$result.Summary.Seiten,$result.Summary.Anfragen,$result.Summary.Fehler,$result.Summary.RestQueue
            }
            'Request' {
                $state.Response=$result; Show-Response $result; Merge-Findings @(Get-PWPassiveFindings $result)
                $state.Project.History=@($state.Project.History)+@([pscustomobject]@{ ZeitpunktUtc=[DateTime]::UtcNow.ToString('o'); Methode=$result.Method; Url=$result.Url; Status=$result.Status; DauerMs=$result.HeaderMs; Typ='Manuell'; Fehler='' })
                $controls.Status.Text='Response received. HTTP '+$result.Status
            }
            'Fuzz' {
                $controls.FuzzResults.ItemsSource=@($result.Rows); Merge-Findings $result.Findings; $state.Project.History=@($state.Project.History)+@($result.History)
                $state.Project.Runs=@($state.Project.Runs)+@([pscustomobject]@{ Typ='Parameter test'; EndeUtc=[DateTime]::UtcNow.ToString('o'); Scope=$state.Project.ScopeUrl; Anfragen=@($result.History).Count; Abgebrochen=$result.Cancelled; Ergebnisse=$result.Rows })
                $controls.Status.Text=if ($result.Cancelled) { 'Parameter test cancelled; partial results kept.' } else { 'Parameter test finished. Results are hints, not proof of exploitability.' }
            }
            'Intruder' {
                $controls.IntruderResults.ItemsSource=@($result.Rows); $state.Project.History=@($state.Project.History)+@($result.History); $state.Project.Runs=@($state.Project.Runs)+@($result.Summary)
                $controls.Status.Text='Intruder ({0}): {1} requests, {2} with reflection. {3}' -f $result.Summary.Modus,$result.Summary.Anfragen,$result.Summary.Reflektiert,$result.Summary.Status
            }
            'DataTable' {
                $controls.DataResults.ItemsSource=@($result.Rows); $state.Project.History=@($state.Project.History)+@($result.History); $state.Project.Runs=@($state.Project.Runs)+@($result.Summary)
                $controls.Status.Text='Data table: {0} rows, {1} requests, {2} with reflection. {3}' -f $result.Summary.Zeilen,$result.Summary.Anfragen,$result.Summary.Reflektiert,$result.Summary.Status
            }
        }
        $state.Dirty=$true; Refresh-Findings; $controls.History.ItemsSource=@($state.Project.History)
    } catch {
        if ($state.Kind -eq 'Request') {
            $state.Project.History=@($state.Project.History)+@([pscustomobject]@{ ZeitpunktUtc=[DateTime]::UtcNow.ToString('o'); Methode=$state.RequestMethod; Url=$state.RequestUrl; Status=0; DauerMs=0; Typ='Manuell'; Fehler=$_.Exception.Message })
            $state.Dirty=$true; $controls.History.ItemsSource=@($state.Project.History)
        }
        if ($state.Control.Cancel) { $controls.Status.Text='Request cancelled.' } else { Show-Error $_ }
    }
    finally { $state.Worker.Dispose(); $state.Worker=$null; $state.Handle=$null; Set-Busy $false }
})
$controls.Start.Add_Click({
    try {
        $options=Get-Options; $pages=0; $depth=0
        if (-not [int]::TryParse($controls.MaxPages.Text,[ref]$pages) -or $pages -lt 1 -or $pages -gt 200) { throw 'Max pages must be between 1 and 200.' }
        if (-not [int]::TryParse($controls.MaxDepth.Text,[ref]$depth) -or $depth -lt 0 -or $depth -gt 10) { throw 'Link depth must be between 0 and 10.' }
        $options.MaxPages=$pages; $options.MaxDepth=$depth; $options.SeedUrls=@(Get-Lines $controls.Seeds.Text); $options.Active=[bool]$controls.Active.IsChecked; Start-Worker 'Scan' $options
    } catch { Show-Error $_ }
})
$cancel={
    if ($state.Control) {
        $state.Control.Cancel=$true; $state.Control.Message='Cancellation requested; partial results are kept ...'
        $request=$state.Control.Request; if ($request) { try { $request.Abort() } catch { } }
    }
}
$controls.Cancel.Add_Click($cancel); $controls.StopFuzz.Add_Click($cancel)
$controls.BrowserCancel.Add_Click($cancel)
$controls.NativeCancel.Add_Click($cancel)
$controls.IntruderCancel.Add_Click($cancel)
$controls.DataCancel.Add_Click($cancel)
$controls.SessionChoice.Add_SelectionChanged({
    if($controls.SessionChoice.SelectedItem){$state.Sessions[$state.CurrentSession].Headers=$controls.AuthHeaders.Text;$state.CurrentSession=[string]$controls.SessionChoice.SelectedItem;$controls.AuthHeaders.Text=$state.Sessions[$state.CurrentSession].Headers;$controls.Status.Text='Active session: '+$state.CurrentSession}
})
$controls.SessionClear.Add_Click({$state.Sessions[$state.CurrentSession]=@{Headers='';Cookies=[Net.CookieContainer]::new();Origin=''};$controls.AuthHeaders.Text='';$controls.Status.Text='Session '+$state.CurrentSession+' cleared.'})
$controls.SessionInfo.Add_Click({$controls.Status.Text='Session {0}: {1} cookies stored (values hidden).' -f $state.CurrentSession,$state.Sessions[$state.CurrentSession].Cookies.Count})
$controls.NativeStart.Add_Click({
    try{
        if(-not $controls.NativeAuthorize.IsChecked){throw 'Authorize the active tests on tab 8 first.'}
        $options=Get-Options;$options.SeedUrls=@(Get-Lines $controls.Seeds.Text);$options.MaxDepth=[int]$controls.MaxDepth.Text;$options.MaxPages=[int]$controls.NativePages.Text;$options.MaxRequests=[int]$controls.NativeRequests.Text;$options.MaxParameters=[int]$controls.NativeParameters.Text;$options.MaxMinutes=[int]$controls.NativeMinutes.Text
        $map=[ordered]@{NativeSqlError='PW-SQL-ERROR';NativeSqlBool='PW-SQL-BOOL';NativeTemplate='PW-TEMPLATE';NativeHtml='PW-HTML';NativeRedirect='PW-REDIRECT';NativeCrlf='PW-CRLF';NativeCors='PW-CORS'}
        $options.Rules=@(foreach($name in $map.Keys){if($controls[$name].IsChecked){$map[$name]}})
        if(-not $options.Rules.Count){throw 'Select at least one rule.'}
        $controls.NativeAuthorize.IsChecked=$false;Start-Worker 'Native' $options
    }catch{Show-Error $_}
})
$controls.RoleCompare.Add_Click({
    try{
        $options=Get-Options;$origin=([Uri]$options.ScopeUrl).GetLeftPart([UriPartial]::Authority)
        foreach($s in $state.Sessions.Values){if($s.Origin -and $s.Origin -ne $origin){throw 'Both sessions must belong to the current target host.'}}
        foreach($s in $state.Sessions.Values){$s.Origin=$origin}
        $roleOptions=@{Url=$controls.RoleUrl.Text.Trim();ScopeUrl=$options.ScopeUrl;Exclude=$options.Exclude;TimeoutSeconds=$options.TimeoutSeconds;HeadersA=(ConvertFrom-PWHeaderText $state.Sessions.A.Headers);HeadersB=(ConvertFrom-PWHeaderText $state.Sessions.B.Headers);CookiesA=$state.Sessions.A.Cookies;CookiesB=$state.Sessions.B.Cookies}
        Start-Worker 'Roles' $roleOptions
    }catch{Show-Error $_}
})
function Choose-Executable([string]$ControlName) {
    $dialog=[Microsoft.Win32.OpenFileDialog]::new(); $dialog.Filter='Programm (*.exe)|*.exe'
    if ($dialog.ShowDialog($window)) { $controls[$ControlName].Text=$dialog.FileName }
}
$controls.ChooseNode.Add_Click({ Choose-Executable 'NodePath' }); $controls.ChooseBrowser.Add_Click({ Choose-Executable 'BrowserPath' })
$controls.BrowserStart.Add_Click({
    try {
        $options=Get-Options; $options.Remove('DelayMs');$options.Remove('CookieContainer')
        $options.NodePath=$controls.NodePath.Text.Trim(); $options.BrowserPath=$controls.BrowserPath.Text.Trim(); $options.SeedUrls=@(Get-Lines $controls.Seeds.Text)
        $options.MaxPages=[int]$controls.BrowserPages.Text; $options.MaxDepth=[int]$controls.MaxDepth.Text; $options.SettleMs=[int]$controls.BrowserSettle.Text; $options.MaxRequests=[int]$controls.BrowserRequests.Text; $options.Xss=[bool]$controls.BrowserXss.IsChecked
        Start-Worker 'Browser' $options
    } catch { Show-Error $_ }
})
$controls.Send.Add_Click({
    try {
        $options=Get-Options; $options.Remove('DelayMs'); $options.Url=$controls.RequestUrl.Text.Trim(); $options.Method=[string]$controls.Method.SelectedItem; $options.Body=$controls.RequestBody.Text
        if ($options.Method -in @('POST','PUT','PATCH','DELETE') -and -not $controls.AllowWrite.IsChecked) { throw 'Aendernde Anfrage zuerst mit der Checkbox im Anfrage-Editor freigeben.' }
        $extra=ConvertFrom-PWHeaderText $controls.RequestHeaders.Text; foreach ($key in $extra.Keys) { $options.Headers[$key]=$extra[$key] }
        $controls.AllowWrite.IsChecked=$false; Start-Worker 'Request' $options
    } catch { Show-Error $_ }
})
$controls.Fuzz.Add_Click({ try { $options=Get-Options; $options.Template=$controls.FuzzUrl.Text.Trim(); $options.Payloads=@(Get-Lines $controls.Payloads.Text); Start-Worker 'Fuzz' $options } catch { Show-Error $_ } })
$controls.IntruderFromRequest.Add_Click({
    $controls.IntruderUrl.Text=$controls.RequestUrl.Text; $controls.IntruderMethod.SelectedItem=[string]$controls.Method.SelectedItem; $controls.IntruderHeaders.Text=$controls.RequestHeaders.Text; $controls.IntruderBody.Text=$controls.RequestBody.Text
    $controls.Status.Text='Taken from tab 3. Mark positions with a pair of section signs.'
})
$controls.IntruderStart.Add_Click({
    try {
        $options=Get-Options
        $m=[string]$controls.IntruderMethod.SelectedItem
        if ($m -in @('POST','PUT','PATCH','DELETE') -and -not $controls.IntruderAuthorize.IsChecked) { throw 'Authorize the state-changing method with the intruder checkbox first.' }
        $max=0; if (-not [int]::TryParse($controls.IntruderMax.Text,[ref]$max) -or $max -lt 1 -or $max -gt 5000) { throw 'Max requests must be between 1 and 5000.' }
        $modeMap=@{ 'Sniper'='Sniper'; 'Battering ram'='BatteringRam'; 'Pitchfork'='Pitchfork'; 'Cluster bomb'='ClusterBomb' }
        $sets=@(); foreach ($n in 'IntruderSet1','IntruderSet2','IntruderSet3','IntruderSet4') { $sets+=,@(Get-Lines $controls[$n].Text) }
        while ($sets.Count -gt 1 -and -not $sets[$sets.Count-1].Count) { $sets=@($sets[0..($sets.Count-2)]) }
        $options.UrlTemplate=$controls.IntruderUrl.Text.Trim(); $options.Method=$m
        $options.HeadersTemplate=$controls.IntruderHeaders.Text; $options.BodyTemplate=$controls.IntruderBody.Text
        $options.Mode=$modeMap[[string]$controls.IntruderMode.SelectedItem]; $options.PayloadSets=$sets; $options.MaxRequests=$max
        $options.EncodeUrl=[bool]$controls.IntruderEncode.IsChecked; $options.AllowStateChanging=[bool]$controls.IntruderAuthorize.IsChecked
        $controls.IntruderAuthorize.IsChecked=$false
        Start-Worker 'Intruder' $options
    } catch { Show-Error $_ }
})
$controls.DataFromRequest.Add_Click({
    $controls.DataUrl.Text=$controls.RequestUrl.Text; $controls.DataMethod.SelectedItem=[string]$controls.Method.SelectedItem; $controls.DataHeaders.Text=$controls.RequestHeaders.Text; $controls.DataBody.Text=$controls.RequestBody.Text
    $controls.Status.Text='Taken from tab 3. Reference table columns as $name in the URL, headers or body.'
})
$controls.DataStart.Add_Click({
    try {
        $options=Get-Options
        $m=[string]$controls.DataMethod.SelectedItem
        if ($m -in @('POST','PUT','PATCH','DELETE') -and -not $controls.DataAuthorize.IsChecked) { throw 'Authorize the state-changing method with the data-table checkbox first.' }
        $max=0; if (-not [int]::TryParse($controls.DataMax.Text,[ref]$max) -or $max -lt 1 -or $max -gt 5000) { throw 'Max requests must be between 1 and 5000.' }
        $options.UrlTemplate=$controls.DataUrl.Text.Trim(); $options.Method=$m
        $options.HeadersTemplate=$controls.DataHeaders.Text; $options.BodyTemplate=$controls.DataBody.Text
        $options.TableText=$controls.DataTable.Text; $options.MaxRequests=$max
        $options.EncodeUrl=[bool]$controls.DataEncode.IsChecked; $options.AllowStateChanging=[bool]$controls.DataAuthorize.IsChecked
        $controls.DataAuthorize.IsChecked=$false
        Start-Worker 'DataTable' $options
    } catch { Show-Error $_ }
})
$proxyTimer.Add_Tick({
    if (-not $state.Proxy) { return }
    if ($state.Proxy.Error) { $controls.Status.Text='Proxy error: '+$state.Proxy.Error }
    elseif ($state.Proxy.Listening) { $controls.Status.Text='{0} | requests: {1}' -f $state.Proxy.Message,$state.Proxy.Count }
    if ($state.Proxy.History.Count -ne $state.ProxyHistCount) {
        $state.ProxyHistCount=$state.Proxy.History.Count
        $controls.ProxyHistory.ItemsSource=@($state.Proxy.History.ToArray())
    }
    if (-not $state.ProxyCurrent -and $state.Proxy.Pending.Count -gt 0) {
        $state.ProxyCurrent=$state.Proxy.Pending.Dequeue()
        $controls.ProxyInterceptBox.Text=$state.ProxyCurrent.Raw
        $controls.ProxyForward.IsEnabled=$true; $controls.ProxyDrop.IsEnabled=$true
        $controls.Status.Text='Intercept: request waiting ('+$state.ProxyCurrent.Url+')'
    }
})
$controls.ProxyStart.Add_Click({
    try {
        if ($state.Proxy) { throw 'Proxy is already running.' }
        Sync-Project
        $port=0; if (-not [int]::TryParse($controls.ProxyPort.Text,[ref]$port) -or $port -lt 1 -or $port -gt 65535) { throw 'Port must be between 1 and 65535.' }
        $state.Proxy=New-PWProxyState -Port $port -ScopeUrl $state.Project.ScopeUrl -Exclude @(Get-Lines $controls.Excludes.Text) -RulesText $controls.ProxyRules.Text -InterceptOn ([bool]$controls.ProxyIntercept.IsChecked) -RulesInScopeOnly ([bool]$controls.ProxyRulesScopeOnly.IsChecked)
        $state.ProxyHistCount=-1
        $ps=[PowerShell]::Create()
        $code='param($module,$state) $ErrorActionPreference="Stop"; Import-Module $module -Force; Start-PWProxyServer -State $state -ModulePath $module'
        [void]$ps.AddScript($code).AddArgument($proxyModulePath).AddArgument($state.Proxy)
        $state.ProxyPS=$ps; $state.ProxyHandle=$ps.BeginInvoke()
        $proxyTimer.Start(); $controls.ProxyStart.IsEnabled=$false; $controls.ProxyStop.IsEnabled=$true
        $controls.Status.Text=('Proxy starting on 127.0.0.1:{0} ... set the browser proxy accordingly.' -f $port)
    } catch { Show-Error $_ }
})
$stopProxy={
    if (-not $state.Proxy) { return }
    $state.Proxy.Stop=$true
    if ($state.ProxyCurrent) { $state.ProxyCurrent.Decision='drop'; $state.ProxyCurrent.Done=$true; $state.ProxyCurrent=$null }
    Start-Sleep -Milliseconds 120
    try { if ($state.ProxyPS) { if (-not $state.ProxyHandle.IsCompleted) { $state.ProxyPS.Stop() }; $state.ProxyPS.Dispose() } } catch {}
    $state.ProxyPS=$null; $state.ProxyHandle=$null; $state.Proxy=$null; $proxyTimer.Stop()
    $controls.ProxyForward.IsEnabled=$false; $controls.ProxyDrop.IsEnabled=$false; $controls.ProxyInterceptBox.Text=''
    $controls.ProxyStart.IsEnabled=$true; $controls.ProxyStop.IsEnabled=$false; $controls.Status.Text='Proxy stopped.'
}
$controls.ProxyStop.Add_Click($stopProxy)
$controls.ProxyApplyRules.Add_Click({
    if ($state.Proxy) {
        $state.Proxy.Rules=@(ConvertFrom-PWProxyRules $controls.ProxyRules.Text)
        $state.Proxy.InterceptOn=[bool]$controls.ProxyIntercept.IsChecked
        $state.Proxy.RulesInScopeOnly=[bool]$controls.ProxyRulesScopeOnly.IsChecked
        $controls.Status.Text=('Rules applied: {0} active.' -f @($state.Proxy.Rules).Count)
    } else { $controls.Status.Text='Proxy is not running; rules apply on start.' }
})
$proxyInterceptToggle={ if ($state.Proxy) { $state.Proxy.InterceptOn=[bool]$controls.ProxyIntercept.IsChecked } }
$controls.ProxyIntercept.Add_Checked($proxyInterceptToggle); $controls.ProxyIntercept.Add_Unchecked($proxyInterceptToggle)
$controls.ProxyForward.Add_Click({
    if ($state.ProxyCurrent) { $state.ProxyCurrent.Edited=$controls.ProxyInterceptBox.Text; $state.ProxyCurrent.Decision='forward'; $state.ProxyCurrent.Done=$true; $state.ProxyCurrent=$null; $controls.ProxyInterceptBox.Text=''; $controls.ProxyForward.IsEnabled=$false; $controls.ProxyDrop.IsEnabled=$false }
})
$controls.ProxyDrop.Add_Click({
    if ($state.ProxyCurrent) { $state.ProxyCurrent.Decision='drop'; $state.ProxyCurrent.Done=$true; $state.ProxyCurrent=$null; $controls.ProxyInterceptBox.Text=''; $controls.ProxyForward.IsEnabled=$false; $controls.ProxyDrop.IsEnabled=$false }
})
$controls.ProxyToRepeater.Add_Click({
    $row=$controls.ProxyHistory.SelectedItem
    if (-not $row) { $controls.Status.Text='Select a row in the proxy history first.'; return }
    $controls.RequestUrl.Text=$row.Url; $controls.Method.SelectedItem=$row.Methode
    $hdrs=@(); foreach ($h in $row.FullHeaders) { if ($h.Name -inotmatch '^(host|content-length|connection|proxy-connection|keep-alive|transfer-encoding)$') { $hdrs+=('{0}: {1}' -f $h.Name,$h.Value) } }
    $controls.RequestHeaders.Text=($hdrs -join "`r`n"); $controls.RequestBody.Text=[string]$row.BodyText; $controls.AllowWrite.IsChecked=$false
    $controls.Tabs.SelectedIndex=2; $controls.Status.Text='Taken from the proxy into tab 3. Review headers and body before sending.'
})
$controls.Baseline.Add_Click({ if ($state.Response) { $state.Baseline=$state.Response; $controls.Status.Text='Response remembered for comparison.' } })
$controls.Compare.Add_Click({
    if (-not $state.Baseline -or -not $state.Response) { $controls.Status.Text='Remember a response first, then send another request.'; return }
    $a=$state.Baseline; $b=$state.Response; $keys=@(@($a.Headers.Keys)+@($b.Headers.Keys) | Sort-Object -Unique); $changed=@($keys | Where-Object { $a.Headers[$_] -cne $b.Headers[$_] })
    $controls.Status.Text='Comparison: HTTP {0} -> {1}; bytes read {2} -> {3}; content identical: {4}; changed headers: {5}' -f $a.Status,$b.Status,$a.BytesRead,$b.BytesRead,($a.Body -ceq $b.Body),($changed -join ', ')
})
$controls.Filter.Add_TextChanged({ Refresh-Findings })
$controls.Findings.Add_SelectionChanged({
    $f=$controls.Findings.SelectedItem
    if ($f) { $state.Finding=$f; $controls.FindingTitle.Text=$f.Titel; $controls.FindingUrl.Text=$f.Url; $controls.Risk.SelectedItem=$f.Risiko; $controls.FindingStatus.SelectedItem=$f.Status; $controls.Evidence.Text=$f.Nachweis; $controls.Remedy.Text=$f.Empfehlung }
})
$controls.NewFinding.Add_Click({
    $state.Finding=$null; $controls.Findings.SelectedItem=$null; $controls.FindingTitle.Text=''; $controls.FindingUrl.Text=$controls.Scope.Text; $controls.Evidence.Text=''; $controls.Remedy.Text=''; $controls.Risk.SelectedIndex=0; $controls.FindingStatus.SelectedIndex=0
    $controls.FindingTitle.Focus() | Out-Null
})
$controls.ApplyFinding.Add_Click({
    if (-not $controls.FindingTitle.Text.Trim()) { $controls.Status.Text='Please enter a title for the finding.'; return }
    if (-not $state.Finding) {
        $state.Finding=New-PWFinding -Title $controls.FindingTitle.Text -Risk ([string]$controls.Risk.SelectedItem) -Url $controls.FindingUrl.Text -Evidence $controls.Evidence.Text -Fix $controls.Remedy.Text -Source 'Manuell'
        $state.Project.Findings=@($state.Project.Findings)+@($state.Finding)
    }
    $f=$state.Finding; $f.Titel=$controls.FindingTitle.Text; $f.Url=$controls.FindingUrl.Text; $f.Risiko=[string]$controls.Risk.SelectedItem; $f.Status=[string]$controls.FindingStatus.SelectedItem; $f.Nachweis=$controls.Evidence.Text; $f.Empfehlung=$controls.Remedy.Text
    $state.Dirty=$true; Refresh-Findings; $controls.Status.Text='Finding applied. Save the project to keep it permanently.'
})
$controls.Replay.Add_Click({
    $row=$controls.History.SelectedItem
    if ($row) { $controls.RequestUrl.Text=$row.Url; $controls.Method.SelectedItem=$row.Methode; $controls.RequestBody.Text=''; $controls.AllowWrite.IsChecked=$false; $controls.Tabs.SelectedIndex=2; $controls.Status.Text='URL and method taken over. Review headers and body before sending.' }
})
function Save-CurrentProject {
    Sync-Project
    $dialog=[Microsoft.Win32.SaveFileDialog]::new(); $dialog.Filter='PowerWEB project (*.json)|*.json'; $dialog.FileName='PowerWEB-project.json'
    if ($dialog.ShowDialog($window)) { Save-PWProject $state.Project $dialog.FileName; $state.Dirty=$false; $controls.Status.Text='Project saved.'; return $true }
    return $false
}
function Confirm-Leave {
    if (-not $state.Dirty) { return $true }
    $answer=[Windows.MessageBox]::Show($window,'Save the project before leaving?','PowerWEB',[Windows.MessageBoxButton]::YesNoCancel)
    if ($answer -eq 'Cancel') { return $false }; if ($answer -eq 'Yes') { return (Save-CurrentProject) }; return $true
}
function Clear-PrivateState {
    foreach ($name in @('AuthHeaders','RequestHeaders','RequestBody','Response','RequestUrl','FuzzUrl','Payloads','Seeds','Filter','Evidence','Remedy','FindingTitle','FindingUrl')) { $controls[$name].Text='' }
    $controls.FuzzResults.ItemsSource=$null; $state.Response=$null; $state.Baseline=$null; $state.Finding=$null; $controls.AllowWrite.IsChecked=$false
    $controls.BrowserResults.ItemsSource=$null
    $state.Sessions=@{A=@{Headers='';Cookies=[Net.CookieContainer]::new();Origin=''};B=@{Headers='';Cookies=[Net.CookieContainer]::new();Origin=''}};$controls.NativeResults.ItemsSource=$null;$controls.RoleUrl.Text='';$controls.NativeAuthorize.IsChecked=$false
}
$controls.SaveProject.Add_Click({ try { [void](Save-CurrentProject) } catch { Show-Error $_ } })
$controls.LoadProject.Add_Click({
    try {
        if (-not (Confirm-Leave)) { return }
        $dialog=[Microsoft.Win32.OpenFileDialog]::new(); $dialog.Filter='PowerWEB project (*.json)|*.json'
        if ($dialog.ShowDialog($window)) { $project=Import-PWProject $dialog.FileName; Clear-PrivateState; $state.Project=$project; Refresh-Project; $state.Dirty=$false; $controls.Status.Text='Project loaded. Re-enter auth headers if needed.' }
    } catch { Show-Error $_ }
})
$controls.NewProject.Add_Click({ try { if (Confirm-Leave) { Clear-PrivateState; $state.Project=New-PWProject; Refresh-Project; $state.Dirty=$false; $controls.Status.Text='New project.' } } catch { Show-Error $_ } })
$controls.Export.Add_Click({
    try {
        Sync-Project
        $dialog=[Microsoft.Win32.SaveFileDialog]::new(); $dialog.Filter='HTML report (*.html)|*.html|JSON project (*.json)|*.json|CSV findings (*.csv)|*.csv'; $dialog.FileName='PowerWEB-report'; $dialog.AddExtension=$true
        if ($dialog.ShowDialog($window)) { $format=@('HTML','JSON','CSV')[$dialog.FilterIndex-1]; Export-PWProjectReport $state.Project $dialog.FileName $format; $controls.Status.Text='Report exported: '+$dialog.FileName }
    } catch { Show-Error $_ }
})
foreach ($name in @('ProjectName','Scope','Notes','MaxPages','MaxDepth','Delay','Timeout','Seeds','Excludes','NodePath','BrowserPath','BrowserPages','BrowserSettle','BrowserRequests')) { $controls[$name].Add_TextChanged({ $state.Dirty=$true }) }
foreach($name in @('NativePages','NativeRequests','NativeParameters','NativeMinutes')){$controls[$name].Add_TextChanged({$state.Dirty=$true})}
foreach($name in @('NativeSqlError','NativeSqlBool','NativeTemplate','NativeHtml','NativeRedirect','NativeCrlf','NativeCors')){$controls[$name].Add_Checked({$state.Dirty=$true});$controls[$name].Add_Unchecked({$state.Dirty=$true})}
$controls.Active.Add_Checked({ $state.Dirty=$true }); $controls.Active.Add_Unchecked({ $state.Dirty=$true })
$controls.BrowserXss.Add_Checked({ $state.Dirty=$true }); $controls.BrowserXss.Add_Unchecked({ $state.Dirty=$true })
$controls.Checklist.Add_CellEditEnding({ $state.Dirty=$true })
$window.Add_Closing({ param($sender,$eventArgs)
    if ($state.Worker) { $eventArgs.Cancel=$true; $controls.Status.Text='Cancel the run first or wait for it to finish.'; return }
    if ($state.Proxy) { & $stopProxy }
    try { if (-not (Confirm-Leave)) { $eventArgs.Cancel=$true } else { $timer.Stop() } } catch { $eventArgs.Cancel=$true; Show-Error $_ }
})
Refresh-Project; $state.Dirty=$false
if (-not $NoShow) { [void]$window.ShowDialog() }
