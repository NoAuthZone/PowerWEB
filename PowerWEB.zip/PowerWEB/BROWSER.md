﻿# Browser-Tests in PowerWEB 3.2

Reiter 7 steuert Chrome oder Edge mit einem eigenen temporaeren Profil.

## Browser einrichten

- Windows PowerShell 5.1, Edge oder Chrome und Node.js 22 oder neuer benoetigt.
- Node.js ist separat unter https://nodejs.org/en/download erhaeltlich.
- Unter Reiter 7 den Pfad zu node.exe und msedge.exe bzw. chrome.exe angeben.
  Vorhandene Programme werden nach Moeglichkeit automatisch erkannt.
- In Reiter 1 Zielbereich, Start-URLs, Ausschluesse und ggf. Anmelde-Header setzen.
- In Reiter 7 Seiten- und Anfragebudget sowie Wartezeit nach dem Laden einstellen.
  Linktiefe und Timeout kommen aus Reiter 1; dessen Pause wird hier nicht benutzt.
- **Browser-Test starten** oeffnet ein unsichtbares, temporaeres Browserprofil.

Der Browser fuehrt Seiten-JavaScript aus, entdeckt Links im gerenderten DOM,
inventarisiert Formulare und Feldnamen ohne Werte und meldet JavaScriptfehler,
Passwortformulare mit GET, Passwortfelder auf HTTP-Seiten sowie Cookieattribute.
Die Seitenuebersicht erscheint in Reiter 7; Befunde und Anfragen in Reitern 2/5.
Formularinventar und Laufgrenzen werden im Projekt und JSON-Bericht gespeichert.

### Aktive XSS-Pruefung

Optional setzt der Browser in bis zu drei vorhandenen Query-Parametern pro Seite
einen eigenen SVG-Eventhandler mit einem eindeutigen Testmarker ein. Erst wenn
der Marker im JavaScript-Kontext der Seite gesetzt wurde, entsteht der Befund
**XSS-Testcode im Browser ausgefuehrt**. Es werden keine Daten ausgelesen oder an
einen externen Empfaenger geschickt. Ein einzelner Payload-Kontext wird getestet;
ein negativer Test schliesst andere XSS-Varianten nicht aus. Parameter, deren Namen
auf Passwoerter, Tokens oder Signaturen hindeuten, werden ausgelassen.

### Browser-Grenzen

- GET/HEAD werden zugelassen; andere abgefangene HTTP-Methoden werden blockiert.
- Zielbereich und Ausschluesse werden fuer abgefangene Seitenanfragen kontrolliert.
- Fremde Ressourcen, Popups, Worker, WebSockets und WebRTC werden blockiert bzw.
  deaktiviert. Das kann Seitenfunktion und damit die Testabdeckung reduzieren.
- Keine automatischen Klickfolgen, Loginformulare, MFA, Datei-Uploads oder SPA-
  Zustandsmodelle. JavaScript-Links werden nach einer begrenzten Wartezeit gesammelt.
- Die Zielkontrolle ist eine Browser-Anwendungskontrolle, keine Betriebssystem-
  Firewall. Browser-interne Dienste koennen Betriebssystem-/Browserverkehr erzeugen.
- Kein persoenliches Browserprofil wird angegeben. Ein separates temporaeres Profil
  wird beim normalen Ende geschlossen und entfernt. Nach einem Absturz koennen
  temporaere Dateien verbleiben; Cookies liegen waehrend des Laufs im Browserprofil.
- Headerwerte und Cookies werden nicht in die PowerWEB-Ergebnisse geschrieben.
  URLs, Feldnamen und manuelle Belege koennen trotzdem vertraulich sein.

## Teststatus

Der Nutzer hat den echten Chrome-Endtest auf seinem Windows-Rechner ausgefuehrt und die PASS-Ausgabe gemeldet. Er umfasst DOM-Linkerkennung, ausgefuehrten XSS-Testcode, einen korrekt maskierten Negativfall, Formularpruefungen, JavaScriptfehler, Scope/Ausschluesse, POST-Sperre und das Weglassen von Zugangsdaten in Ergebnissen. Das bestaetigt diese Testfaelle, keine vollstaendige Browser-Testabdeckung.

In der eingeschraenkten Agentenumgebung scheitert der Browserstart weiterhin vor der Testseite. Die Browserimplementierung bleibt bei der Entfernung der externen Scan-Anbindung unveraendert.

Reproduzieren aus dem entpackten PowerWEB-Ordner:

```powershell
node .\tests\Test-BrowserScope.mjs
node .\tests\Test-Browser.mjs 'C:\Program Files\Google\Chrome\Application\chrome.exe'
```

Der Endtest verwendet ausschliesslich einen lokalen Testserver und ein separates Browserprofil. Die nativen Sitzungen A/B werden noch nicht in den Browser uebernommen; Anmeldeheader koennen separat verwendet werden.

## Lizenz

Der mitgelieferte Code steht unter MIT. Browser und Node.js sind separate Systemvoraussetzungen mit eigenen Lizenzen. Es werden keine fremden Scan-Engines mitgeliefert.