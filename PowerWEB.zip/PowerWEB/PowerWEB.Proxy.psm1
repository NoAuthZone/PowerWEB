# SPDX-License-Identifier: MIT
# Eigener, unabhaengig geschriebener Forward-Proxy fuer PowerWEB. Faengt HTTP ab,
# erlaubt das Veraendern von Headern (Regeln oder manuelles Intercept) und leitet
# weiter. HTTPS (CONNECT) wird in dieser Stufe nur getunnelt, nicht aufgebrochen.
# Nur im vereinbarten Testumfang verwenden.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'PowerWEB.Audit.psm1')

# Verbindungsbezogene bzw. hop-by-hop Header, die der Proxy nicht weiterreicht.
$script:PWHopByHop=@('connection','proxy-connection','keep-alive','transfer-encoding','te','trailer','upgrade','proxy-authorization','proxy-authenticate')

function New-PWProxyState {
    param(
        [int]$Port=8081,[string]$ScopeUrl='',[string[]]$Exclude=@(),
        [string]$RulesText='',[bool]$InterceptOn=$false,[bool]$RulesInScopeOnly=$true)
    $s=[hashtable]::Synchronized(@{})
    $s.Port=$Port; $s.ScopeUrl=$ScopeUrl; $s.Exclude=$Exclude
    $s.Rules=@(ConvertFrom-PWProxyRules $RulesText)
    $s.InterceptOn=$InterceptOn; $s.RulesInScopeOnly=$RulesInScopeOnly
    $s.Stop=$false; $s.Listening=$false; $s.Error=''; $s.Message=''; $s.Count=0
    $s.Pending=[Collections.Queue]::Synchronized([Collections.Queue]::new())
    $s.History=[Collections.ArrayList]::Synchronized([Collections.ArrayList]::new())
    return $s
}

function ConvertFrom-PWProxyRules {
    # Mini-Syntax, eine Regel pro Zeile:
    #   set  Name: Wert      -> Header setzen/ersetzen (Anfrage)
    #   add  Name: Wert      -> Header zusaetzlich anhaengen
    #   remove Name          -> Header entfernen
    #   replace /regex/ersatz/  -> Regex auf jede Headerzeile "Name: Wert" (nicht Request-Zeile)
    # Zeilen mit # sind Kommentare. Ungueltige Zeilen werden ignoriert.
    param([AllowEmptyString()][string]$Text='')
    $rules=[Collections.Generic.List[object]]::new()
    foreach ($raw in ($Text -split '\r?\n')) {
        $line=$raw.Trim(); if (-not $line -or $line.StartsWith('#')) { continue }
        $sp=$line.IndexOf(' '); if ($sp -lt 1) { continue }
        $op=$line.Substring(0,$sp).ToLowerInvariant(); $rest=$line.Substring($sp+1).Trim()
        switch ($op) {
            'set'    { $c=$rest.IndexOf(':'); if ($c -ge 1) { $rules.Add([pscustomobject]@{Op='set';Name=$rest.Substring(0,$c).Trim();Value=$rest.Substring($c+1).Trim()}) } }
            'add'    { $c=$rest.IndexOf(':'); if ($c -ge 1) { $rules.Add([pscustomobject]@{Op='add';Name=$rest.Substring(0,$c).Trim();Value=$rest.Substring($c+1).Trim()}) } }
            'remove' { $rules.Add([pscustomobject]@{Op='remove';Name=$rest.Trim();Value=''}) }
            'replace' {
                if ($rest.Length -ge 3 -and $rest[0] -eq '/') {
                    $end=$rest.LastIndexOf('/'); $mid=$rest.IndexOf('/',1)
                    if ($mid -gt 1 -and $end -gt $mid) {
                        $pat=$rest.Substring(1,$mid-1); $rep=$rest.Substring($mid+1,$end-$mid-1)
                        try { [void][regex]::new($pat); $rules.Add([pscustomobject]@{Op='replace';Name=$pat;Value=$rep}) } catch { }
                    }
                }
            }
        }
    }
    return $rules.ToArray()
}

function Read-PWLine {
    # Liest eine Zeile (bis LF) als ASCII vom Stream, ohne CR/LF. $null am Ende.
    param([IO.Stream]$Stream)
    $bytes=[Collections.Generic.List[byte]]::new()
    while ($true) {
        $b=$Stream.ReadByte()
        if ($b -lt 0) { if ($bytes.Count -eq 0) { return $null } else { break } }
        if ($b -eq 10) { break }
        if ($b -ne 13) { $bytes.Add([byte]$b) }
    }
    return [Text.Encoding]::ASCII.GetString($bytes.ToArray())
}

function Read-PWHead {
    # Liest Request-Zeile und Header bis zur Leerzeile. Gibt Struktur zurueck.
    param([IO.Stream]$Stream)
    $requestLine=Read-PWLine $Stream
    if ($null -eq $requestLine -or -not $requestLine.Trim()) { return $null }
    $headers=[Collections.Generic.List[object]]::new()
    while ($true) {
        $line=Read-PWLine $Stream
        if ($null -eq $line -or $line -eq '') { break }
        $c=$line.IndexOf(':'); if ($c -lt 1) { continue }
        $headers.Add([pscustomobject]@{ Name=$line.Substring(0,$c).Trim(); Value=$line.Substring($c+1).Trim() })
    }
    $parts=$requestLine -split ' ',3
    [pscustomobject]@{ Method=$parts[0]; Target=$(if ($parts.Count -gt 1){$parts[1]}else{''}); Version=$(if ($parts.Count -gt 2){$parts[2]}else{'HTTP/1.1'}); Headers=$headers }
}

function Get-PWHeader { param($Head,[string]$Name) foreach ($h in $Head.Headers) { if ($h.Name -ieq $Name) { return $h.Value } } return $null }

function ConvertTo-PWHeadText {
    param($Head)
    $sb=[Text.StringBuilder]::new()
    [void]$sb.Append(('{0} {1} {2}' -f $Head.Method,$Head.Target,$Head.Version)); [void]$sb.Append("`r`n")
    foreach ($h in $Head.Headers) { [void]$sb.Append(('{0}: {1}' -f $h.Name,$h.Value)); [void]$sb.Append("`r`n") }
    $sb.ToString()
}

function ConvertFrom-PWHeadText {
    # Parst editierten Rohkopf (Request-Zeile + Header) zurueck in die Struktur.
    param([string]$Text)
    $lines=$Text -split '\r?\n'
    $requestLine=$lines[0]
    $headers=[Collections.Generic.List[object]]::new()
    for ($i=1; $i -lt $lines.Count; $i++) {
        $line=$lines[$i]; if (-not $line.Trim()) { continue }
        $c=$line.IndexOf(':'); if ($c -lt 1) { continue }
        $headers.Add([pscustomobject]@{ Name=$line.Substring(0,$c).Trim(); Value=$line.Substring($c+1).Trim() })
    }
    $parts=$requestLine.Trim() -split ' ',3
    [pscustomobject]@{ Method=$parts[0]; Target=$(if ($parts.Count -gt 1){$parts[1]}else{''}); Version=$(if ($parts.Count -gt 2){$parts[2]}else{'HTTP/1.1'}); Headers=$headers }
}

function Invoke-PWProxyRules {
    # Wendet die Regeln auf die Header-Liste eines Head-Objekts an (in place, neue Liste).
    param($Head,[object[]]$Rules)
    $list=[Collections.Generic.List[object]]::new()
    foreach ($h in $Head.Headers) { $list.Add([pscustomobject]@{Name=$h.Name;Value=$h.Value}) }
    foreach ($rule in $Rules) {
        switch ($rule.Op) {
            'set' {
                $found=$false
                foreach ($h in $list) { if ($h.Name -ieq $rule.Name) { $h.Value=$rule.Value; $found=$true } }
                if (-not $found) { $list.Add([pscustomobject]@{Name=$rule.Name;Value=$rule.Value}) }
            }
            'add' { $list.Add([pscustomobject]@{Name=$rule.Name;Value=$rule.Value}) }
            'remove' { $keep=[Collections.Generic.List[object]]::new(); foreach ($h in $list) { if ($h.Name -inotlike $rule.Name) { $keep.Add($h) } }; $list=$keep }
            'replace' {
                foreach ($h in $list) {
                    try { $combined=[regex]::Replace(('{0}: {1}' -f $h.Name,$h.Value),$rule.Name,$rule.Value)
                        $c=$combined.IndexOf(':'); if ($c -ge 1) { $h.Name=$combined.Substring(0,$c).Trim(); $h.Value=$combined.Substring($c+1).Trim() }
                    } catch { }
                }
            }
        }
    }
    $Head.Headers=$list
    return $Head
}

function Send-PWProxyUpstream {
    # Leitet eine (ggf. veraenderte) HTTP-Anfrage an den Zielserver weiter und gibt
    # Status, Antwortheader und Rohbytes zurueck. Nutzt HttpWebRequest.
    param([string]$Method,[string]$Url,$Headers,[byte[]]$Body,[int]$TimeoutSeconds=30)
    $req=[Net.HttpWebRequest]::Create($Url)
    $req.Method=$Method; $req.AllowAutoRedirect=$false; $req.KeepAlive=$false
    $req.AutomaticDecompression=[Net.DecompressionMethods]::None
    $req.Timeout=$TimeoutSeconds*1000; $req.ReadWriteTimeout=$TimeoutSeconds*1000
    $req.ServicePoint.Expect100Continue=$false
    foreach ($h in $Headers) {
        $lower=$h.Name.ToLowerInvariant()
        if ($lower -in $script:PWHopByHop -or $lower -in @('host','content-length','accept-encoding','date','expect')) { continue }
        try {
            switch ($lower) {
                'content-type' { $req.ContentType=$h.Value }
                'accept'       { $req.Accept=$h.Value }
                'user-agent'   { $req.UserAgent=$h.Value }
                'referer'      { $req.Referer=$h.Value }
                'if-modified-since' { $req.IfModifiedSince=[DateTime]::Parse($h.Value) }
                'range'        { }
                default        { $req.Headers[$h.Name]=$h.Value }
            }
        } catch { }
    }
    if ($null -ne $Body -and $Body.Length -gt 0 -and $Method -notin @('GET','HEAD')) {
        $req.ContentLength=$Body.Length
        $rs=$req.GetRequestStream(); try { $rs.Write($Body,0,$Body.Length) } finally { $rs.Dispose() }
    }
    $resp=$null
    try { $resp=[Net.HttpWebResponse]$req.GetResponse() }
    catch [Net.WebException] { if ($null -eq $_.Exception.Response) { throw }; $resp=[Net.HttpWebResponse]$_.Exception.Response }
    try {
        $ms=[IO.MemoryStream]::new()
        if ($Method -ne 'HEAD') { $rstream=$resp.GetResponseStream(); $buf=New-Object byte[] 8192; while (($n=$rstream.Read($buf,0,$buf.Length)) -gt 0) { $ms.Write($buf,0,$n) } }
        $respHeaders=[Collections.Generic.List[object]]::new()
        foreach ($key in $resp.Headers.AllKeys) {
            if ($key.ToLowerInvariant() -in $script:PWHopByHop -or $key -ieq 'content-length') { continue }
            foreach ($val in $resp.Headers.GetValues($key)) { $respHeaders.Add([pscustomobject]@{Name=$key;Value=$val}) }
        }
        [pscustomobject]@{ Status=[int]$resp.StatusCode; Description=[string]$resp.StatusDescription; Headers=$respHeaders; Body=$ms.ToArray() }
    } finally { if ($resp) { $resp.Close() } }
}

function Write-PWClientResponse {
    param([IO.Stream]$Stream,[int]$Status,[string]$Description,$Headers,[byte[]]$Body)
    $sb=[Text.StringBuilder]::new()
    [void]$sb.Append(('HTTP/1.1 {0} {1}' -f $Status,$Description)); [void]$sb.Append("`r`n")
    foreach ($h in $Headers) { [void]$sb.Append(('{0}: {1}' -f $h.Name,$h.Value)); [void]$sb.Append("`r`n") }
    $len=$(if ($null -ne $Body) { $Body.Length } else { 0 })
    [void]$sb.Append(('Content-Length: {0}' -f $len)); [void]$sb.Append("`r`n")
    [void]$sb.Append("Connection: close`r`n`r`n")
    $headBytes=[Text.Encoding]::ASCII.GetBytes($sb.ToString())
    $Stream.Write($headBytes,0,$headBytes.Length)
    if ($len -gt 0) { $Stream.Write($Body,0,$Body.Length) }
    $Stream.Flush()
}

function Write-PWSimpleResponse {
    param([IO.Stream]$Stream,[int]$Status,[string]$Description,[string]$Text='')
    $body=[Text.Encoding]::UTF8.GetBytes($Text)
    Write-PWClientResponse $Stream $Status $Description @([pscustomobject]@{Name='Content-Type';Value='text/plain; charset=utf-8'}) $body
}

function Invoke-PWTunnel {
    # HTTPS-CONNECT: transparenter Tunnel ohne Inhaltspruefung.
    param([Net.Sockets.TcpClient]$Client,[string]$HostName,[int]$TargetPort,$State)
    $upstream=[Net.Sockets.TcpClient]::new()
    try {
        $upstream.Connect($HostName,$TargetPort)
        $cs=$Client.GetStream(); $us=$upstream.GetStream()
        $ok=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 Connection Established`r`n`r`n")
        $cs.Write($ok,0,$ok.Length); $cs.Flush()
        $t1=$cs.CopyToAsync($us); $t2=$us.CopyToAsync($cs)
        while (-not ($t1.IsCompleted -and $t2.IsCompleted)) { if ($State.Stop) { break }; [Threading.Tasks.Task]::WaitAny(@($t1,$t2),200) | Out-Null }
    } catch { } finally { $upstream.Close() }
}

function Add-PWProxyHistory {
    param($State,[string]$Method,[string]$Url,[int]$Status,[int]$Bytes,[bool]$InScope,[bool]$Modified,$Head,[byte[]]$Body)
    # Sensible Header nur maskiert anzeigen; vollstaendige Anfrage nur im Speicher fuer "an Reiter 3".
    $preview=@(); foreach ($h in $Head.Headers) { $v=if ($h.Name -imatch 'authorization|cookie|proxy-authorization') { '[hidden]' } else { $h.Value }; $preview+=('{0}: {1}' -f $h.Name,$v) }
    $item=[pscustomobject]@{
        Zeit=[DateTime]::Now.ToString('HH:mm:ss'); Methode=$Method; Url=$Url; HTTP=$Status; Bytes=$Bytes
        ImScope=$InScope; Veraendert=$Modified
        RawMethod=$Method; RawTarget=$Url; RawHeaders=($preview -join "`r`n")
        FullHeaders=$Head.Headers; BodyText=$(if ($null -ne $Body -and $Body.Length -gt 0){ try { [Text.Encoding]::UTF8.GetString($Body) } catch { '' } } else { '' })
    }
    [void]$State.History.Add($item)
    while ($State.History.Count -gt 500) { $State.History.RemoveAt(0) }
}

function Invoke-PWProxyConnection {
    [CmdletBinding()]
    param([Net.Sockets.TcpClient]$Client,$State)
    try {
        $Client.ReceiveTimeout=30000; $Client.SendTimeout=30000
        $stream=$Client.GetStream()
        $head=Read-PWHead $stream
        if ($null -eq $head) { return }
        $State.Count++

        if ($head.Method -eq 'CONNECT') {
            $hp=$head.Target -split ':',2; $h=$hp[0]; $p=$(if ($hp.Count -gt 1){[int]$hp[1]}else{443})
            Add-PWProxyHistory $State 'CONNECT' ('https://'+$head.Target) 0 0 $false $false $head $null
            Invoke-PWTunnel $Client $h $p $State
            return
        }

        # Absolute-Form-Ziel des Forward-Proxys.
        $url=$head.Target
        if ($url -notmatch '^https?://') { Write-PWSimpleResponse $stream 400 'Bad Request' 'PowerWEB proxy expects absolute URLs (forward proxy).'; return }

        # Request-Body per Content-Length lesen.
        $body=$null; $clen=Get-PWHeader $head 'Content-Length'; $total=0
        if ($clen -and [int]::TryParse($clen,[ref]$total) -and $total -gt 0 -and $total -le 20971520) {
            $body=New-Object byte[] $total; $read=0
            while ($read -lt $total) { $n=$stream.Read($body,$read,$total-$read); if ($n -le 0) { break }; $read+=$n }
        }

        $inScope=if ([string]::IsNullOrWhiteSpace([string]$State.ScopeUrl)) { $true } else { [bool](Test-PWScope $url $State.ScopeUrl $State.Exclude) }
        $modified=$false
        $applyEdits = $inScope -or (-not $State.RulesInScopeOnly)

        if ($applyEdits -and @($State.Rules).Count) { $head=Invoke-PWProxyRules $head @($State.Rules); $modified=$true }

        if ($State.InterceptOn -and $inScope) {
            $item=[hashtable]::Synchronized(@{ Raw=(ConvertTo-PWHeadText $head); Url=$url; Done=$false; Decision=''; Edited='' })
            $State.Pending.Enqueue($item)
            while (-not $item.Done -and -not $State.Stop) { Start-Sleep -Milliseconds 40 }
            if ($State.Stop) { try { Write-PWSimpleResponse $stream 504 'Gateway Timeout' 'Proxy stopped.' } catch {}; return }
            if ($item.Decision -eq 'drop') { Write-PWSimpleResponse $stream 504 'Dropped' 'Request dropped by the tester.'; return }
            if ($item.Edited) { $head=ConvertFrom-PWHeadText $item.Edited; $url=$head.Target; $modified=$true }
        }

        try {
            $resp=Send-PWProxyUpstream $head.Method $url $head.Headers $body
            Write-PWClientResponse $stream $resp.Status $resp.Description $resp.Headers $resp.Body
            Add-PWProxyHistory $State $head.Method $url $resp.Status $resp.Body.Length $inScope $modified $head $body
        } catch {
            try { Write-PWSimpleResponse $stream 502 'Bad Gateway' ('Weiterleitung fehlgeschlagen: '+$_.Exception.Message) } catch {}
            Add-PWProxyHistory $State $head.Method $url 0 0 $inScope $modified $head $body
        }
    } catch { } finally { try { $Client.Close() } catch {} }
}

function Start-PWProxyServer {
    # Laeuft im Hintergrund-Runspace. Nimmt Verbindungen an und bearbeitet jede in
    # einem eigenen Pool-Runspace, damit paralleler Browser-Verkehr funktioniert.
    [CmdletBinding()]
    param($State,[string]$ModulePath)
    $listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$State.Port)
    try { $listener.Start() } catch { $State.Error='Listener: '+$_.Exception.Message; $State.Listening=$false; return }
    $State.Listening=$true; $State.Message=('Proxy running on 127.0.0.1:{0}' -f $State.Port)
    $iss=[Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    try { $iss.ImportPSModule(@($ModulePath)) } catch {}
    $pool=[RunspaceFactory]::CreateRunspacePool($iss); $pool.SetMinRunspaces(1); [void]$pool.SetMaxRunspaces(32); $pool.Open()
    # Modul nur importieren, falls es im Pool-Runspace noch nicht geladen ist.
    $handlerCode='param($client,$state,$module) if (-not (Get-Command Invoke-PWProxyConnection -ErrorAction SilentlyContinue)) { Import-Module $module -Force }; Invoke-PWProxyConnection -Client $client -State $state'
    $active=[Collections.Generic.List[object]]::new()
    try {
        while (-not $State.Stop) {
            if ($listener.Pending()) {
                $client=$listener.AcceptTcpClient()
                $ps=[PowerShell]::Create(); $ps.RunspacePool=$pool
                [void]$ps.AddScript($handlerCode).AddArgument($client).AddArgument($State).AddArgument($ModulePath)
                $active.Add(@{ PS=$ps; Handle=$ps.BeginInvoke() })
            } else { Start-Sleep -Milliseconds 15 }
            for ($i=$active.Count-1; $i -ge 0; $i--) { if ($active[$i].Handle.IsCompleted) { try { $active[$i].PS.EndInvoke($active[$i].Handle) } catch {}; $active[$i].PS.Dispose(); $active.RemoveAt($i) } }
        }
    } finally {
        try { $listener.Stop() } catch {}
        foreach ($a in $active) { try { $a.PS.Stop() } catch {}; try { $a.PS.Dispose() } catch {} }
        try { $pool.Close() } catch {}
        $State.Listening=$false; $State.Message='Proxy stopped.'
    }
}

Export-ModuleMember -Function New-PWProxyState,ConvertFrom-PWProxyRules,Read-PWHead,Get-PWHeader,ConvertTo-PWHeadText,ConvertFrom-PWHeadText,Invoke-PWProxyRules,Send-PWProxyUpstream,Invoke-PWProxyConnection,Start-PWProxyServer
