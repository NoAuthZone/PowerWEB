# PowerWEB 3.2: Pruefbericht

Die externe Scan-Anbindung wurde auf Nutzerwunsch aus der aktiven Anwendung entfernt: Oberflaechenreiter, API-Code, Hintergrundauftraege, API-Schluesselfeld, Einstellungen und zugehoerige Tests. Der Browser bleibt Reiter 7, die eigene Engine ist jetzt Reiter 8.

Vorhandene Projekte bleiben lesbar. Historische Befunde und Laufberichte bleiben Projektdaten. Obsolete Verbindungseinstellungen werden von der Oberflaeche nicht verwendet und beim naechsten Speichern nicht erneut uebernommen.

## Pruefungen

- PowerShell-Syntax und WPF-Integration: HTTP-Anfragen, Zielbegrenzung, Crawler, Redirects, Parameterpruefungen, Abbruch, Projektdateien und Berichte.
- Eigene Engine: sieben positive Regel-Testfaelle und negative Kontrollen, strukturierte Belege, Maskierung, CSV-/HTML-Export, Anfrage-/Seitenlimits, gekuerzte und binaere Antworten.
- Sitzungen: zwei getrennte Logins, Rollenvergleich, Bindung an den Zielursprung und Zuruecksetzen bei neuen Projekten.
- TLS-Zertifikatsablehnung unter Windows PowerShell 5.1 sowie Legacy-CLI-Tests.
- Browser: Syntax und Scope-Tests. Der Nutzer bestaetigte den echten Chrome-Endtest mit PASS; Browsercode in dieser Version unveraendert.
- Paket: Dateiinhalte und Start aus dem entpackten ZIP.

## Grenzen

Kontrollierte lokale Testfaelle garantieren keine vollstaendige Schwachstellenerkennung. Die eigene Engine untersucht GET-Query-Parameter und ausgewaehlte Header. HTML-Reflexion ist kein XSS-Nachweis; SQL-Muster bleiben Verdachtsbefunde. Browser-Sitzungen sind noch nicht mit den nativen Cookie-Speichern verbunden.

Der Browserstart ist in der eingeschraenkten Agentenumgebung weiterhin blockiert; der erfolgreiche echte Endtest stammt vom Rechner des Nutzers. Windows PowerShell 5.1 ist die vorgesehene Laufzeit. Der fruehere TLS-Zusatzversuch unter PowerShell 7 scheiterte an der Windows-TLS-Initialisierung und gilt nicht als bestandener TLS-Test.
