// SPDX-License-Identifier: MIT
// Native Node.js + Chromium DevTools Protocol. No third-party source or packages.
import {spawn} from 'node:child_process';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {createInterface} from 'node:readline';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';

let config, cancelled=false;
const emit=(type,data)=>process.stdout.write(JSON.stringify({type,data})+'\n');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const findings=[],history=[],pages=[],warnings=[];
function finding(title,risk,url,evidence,fix) {
  findings.push({Id:randomUUID().slice(0,10),Risiko:risk,Titel:title,Url:url,Status:'Offen',Quelle:'Browser',Nachweis:evidence,Empfehlung:fix});
}
export function inScope(raw,scope,exclude=[]) {
  try {
    const u=new URL(raw),s=new URL(scope),p=s.pathname.replace(/\/$/,''),decoded=decodeURIComponent(u.pathname+u.search).toLowerCase();
    return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password&&u.origin===s.origin&&
      (!p||u.pathname===p||u.pathname.startsWith(p+'/'))&&!/%(?:2f|5c|2e|25)/i.test(u.pathname)&&
      !exclude.some(x=>x&&decoded.includes(x.toLowerCase()));
  } catch {return false;}
}
class CDP {
  constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();this.listeners=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}}else{for(const fn of this.listeners) Promise.resolve(fn(m)).catch(e=>{if(warnings.length<20)warnings.push('Browser-Ereignis: '+e.message);});}});
    ws.addEventListener('close',()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error('Browser-Verbindung beendet: '+p.method));}this.pending.clear();});
  }
  call(method,params={},sessionId){return new Promise((resolve,reject)=>{const id=++this.id,timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('Browser-Zeitlimit: '+method));},15000);this.pending.set(id,{resolve,reject,timer,method});this.ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}
}
async function run(cfg){
  if(Number(process.versions.node.split('.')[0])<22)throw new Error('Node.js 22 oder neuer erforderlich.');
  if(!inScope(cfg.ScopeUrl,cfg.ScopeUrl,cfg.Exclude))throw new Error('Ungueltiger oder ausgeschlossener Zielbereich.');
  const maxPages=Number(cfg.MaxPages??10),maxDepth=Number(cfg.MaxDepth??2),timeout=Number(cfg.TimeoutSeconds??15)*1000,settle=Number(cfg.SettleMs??1000),maxRequests=Number(cfg.MaxRequests??500);
  if(!Number.isInteger(maxPages)||maxPages<1||maxPages>50||maxDepth<0||maxDepth>10||timeout<1000||timeout>60000||settle<100||settle>10000||maxRequests<1||maxRequests>5000)throw new Error('Ungueltige Browser-Limits.');
  const exclude=cfg.Exclude??[],headers=cfg.Headers??{};
  for(const [k,v] of Object.entries(headers)){if(!/^[\w!#$%&'*+.^`|~-]+$/.test(k)||/[\r\n]/.test(v)||/^(host|content-length|connection|transfer-encoding|proxy-authorization)$/i.test(k))throw new Error('Ungueltiger Browser-Header.');}
  let browser,cdp,ws,blocked=0,allowed=0,navErrors=0,currentUrl=cfg.ScopeUrl,activeProbe=false,session;
  const start=new Date().toISOString(),requestStarts=new Map(),seen=new Set(),queue=[];
  for(const seed of [cfg.ScopeUrl,...(cfg.SeedUrls??[])]){if(!inScope(seed,cfg.ScopeUrl,exclude))throw new Error('Start-URL ausserhalb Scope.');const u=new URL(seed);u.hash='';if(!seen.has(u.href)){seen.add(u.href);queue.push({url:u.href,depth:0});}}
  const tempRoot=path.resolve(tmpdir()),profile=await mkdtemp(path.join(tempRoot,'powerweb-browser-'));
  try {
    browser=spawn(cfg.BrowserPath,['--headless=new','--disable-gpu','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1',`--user-data-dir=${profile}`,'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-quic','--disable-features=MediaRouter,OptimizationHints,Translate','about:blank'],{windowsHide:true,stdio:['ignore','ignore',process.env.PW_BROWSER_DEBUG?'pipe':'ignore']});
    if(browser.stderr)browser.stderr.on('data',b=>process.stderr.write(b));
    let spawnError;browser.on('error',e=>{spawnError=e;});
    const until=Date.now()+15000;let portInfo;
    while(Date.now()<until&&!cancelled){if(spawnError)throw spawnError;if(browser.exitCode!==null)throw new Error('Browser wurde vorzeitig beendet.');try{portInfo=(await readFile(path.join(profile,'DevToolsActivePort'),'utf8')).trim().split(/\r?\n/);break;}catch{}await wait(100);}
    if(!portInfo)throw new Error(cancelled?'Browserstart abgebrochen.':'Browser-Debugschnittstelle nicht verfuegbar.');
    ws=new WebSocket(`ws://127.0.0.1:${Number(portInfo[0])}${portInfo[1]}`);await Promise.race([once(ws,'open'),wait(5000).then(()=>{throw new Error('Browser-Verbindungszeitlimit');})]);cdp=new CDP(ws);
    const {browserContextId}=await cdp.call('Target.createBrowserContext',{disposeOnDetach:true});
    await cdp.call('Browser.setDownloadBehavior',{behavior:'deny',browserContextId});
    const {targetId}=await cdp.call('Target.createTarget',{url:'about:blank',browserContextId});
    session=(await cdp.call('Target.attachToTarget',{targetId,flatten:true})).sessionId;
    const send=(method,params={})=>cdp.call(method,params,session);
    cdp.listeners.push(async m=>{
      if(m.method==='Target.attachedToTarget'){
        const child=m.params;
        if(child.targetInfo.targetId!==targetId){blocked++;try{await cdp.call('Target.closeTarget',{targetId:child.targetInfo.targetId});}catch{}return;}
        try{await cdp.call('Runtime.runIfWaitingForDebugger',{},child.sessionId);}catch{}
        return;
      }
      if(m.sessionId!==session)return;
      const p=m.params??{};
      if(m.method==='Fetch.requestPaused'){
        const accept=!cancelled&&allowed<maxRequests&&['GET','HEAD'].includes(p.request.method)&&inScope(p.request.url,cfg.ScopeUrl,exclude);
        if(!accept){blocked++;await send('Fetch.failRequest',{requestId:p.requestId,errorReason:'BlockedByClient'});return;}
        allowed++;
        const merged={...p.request.headers};
        for(const [key,value] of Object.entries(headers)){for(const old of Object.keys(merged)){if(old.toLowerCase()===key.toLowerCase())delete merged[old];}merged[key]=String(value);}
        await send('Fetch.continueRequest',{requestId:p.requestId,headers:Object.entries(merged).map(([name,value])=>({name,value:String(value)}))});
      }else if(m.method==='Network.requestWillBeSent'){requestStarts.set(p.requestId,{time:Date.now(),method:p.request.method});}
      else if(m.method==='Network.responseReceived'&&inScope(p.response.url,cfg.ScopeUrl,exclude)){
        const r=requestStarts.get(p.requestId);
        history.push({ZeitpunktUtc:new Date().toISOString(),Methode:r?.method??'GET',Url:p.response.url,Status:p.response.status,DauerMs:r?Date.now()-r.time:0,Typ:activeProbe?'Browser-XSS':'Browser',Fehler:''});
      }else if(m.method==='Runtime.exceptionThrown'&&!activeProbe){
        if(findings.filter(x=>x.Titel==='JavaScript-Laufzeitfehler').length<20)finding('JavaScript-Laufzeitfehler','Info',currentUrl,p.exceptionDetails.text+'; Browserfehler, kein bestaetigter Sicherheitsbefund.','Fehler im Browser reproduzieren und Ursache untersuchen.');
      }else if(m.method==='Page.javascriptDialogOpening'){await send('Page.handleJavaScriptDialog',{accept:false});}
    });
    await send('Page.enable');await send('Runtime.enable');await send('Network.enable');await send('Network.setBypassServiceWorker',{bypass:true});
    await send('Fetch.enable',{patterns:[{urlPattern:'*',requestStage:'Request'}]});
    // Pause and close newly created popups, out-of-process frames and workers.
    await cdp.call('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true,filter:[{type:'page'},{type:'iframe'},{type:'worker'},{type:'service_worker'},{type:'shared_worker'},{exclude:true}]});
    await send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true});
    // Keep the exploratory browser read-only and prevent independent network workers/popups.
    await send('Page.addScriptToEvaluateOnNewDocument',{source:`(()=>{const blocked=function(){throw new Error('PowerWEB: Funktion fuer diesen Test gesperrt')};for(const k of ['Worker','SharedWorker','WebSocket','RTCPeerConnection','webkitRTCPeerConnection','EventSource']){try{Object.defineProperty(window,k,{value:blocked,writable:false,configurable:false})}catch{}}try{Object.defineProperty(window,'open',{value:()=>null,writable:false,configurable:false})}catch{}try{Object.defineProperty(navigator,'sendBeacon',{value:()=>false})}catch{}try{if(navigator.serviceWorker)Object.defineProperty(navigator.serviceWorker,'register',{value:blocked})}catch{}})();`});
    async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:false,timeout:3000});if(r.exceptionDetails)throw new Error('Browser-Auswertung fehlgeschlagen.');return r.result.value;}
    async function navigate(url){
      currentUrl=url;
      const r=await send('Page.navigate',{url});if(r.errorText)throw new Error(r.errorText);
      const end=Date.now()+timeout;
      while(Date.now()<end&&!cancelled){try{if(await evaluate("document.readyState === 'complete'")){await wait(settle);return;}}catch{}await wait(100);}
      if(cancelled)return;await send('Page.stopLoading');throw new Error('Seitenladezeit ueberschritten.');
    }
    while(queue.length&&pages.length<maxPages&&!cancelled&&allowed<maxRequests){
      const item=queue.shift();emit('progress',`Browser ${pages.length+1}/${maxPages}: ${item.url}`);
      try{
        await navigate(item.url);if(cancelled)break;
        const snapshot=await evaluate(`JSON.parse(JSON.stringify({url:location.href,title:document.title,links:[...document.querySelectorAll('a[href]')].slice(0,1000).map(a=>a.href),forms:[...document.forms].slice(0,50).map(f=>({action:f.action,method:f.method,fields:[...f.elements].slice(0,100).map(e=>({name:e.name,type:e.type}))})),passwords:document.querySelectorAll('input[type=password]').length,mixed:[...document.querySelectorAll('[src]')].filter(e=>e.src&&e.src.startsWith('http:')).length}))`);
        if(!inScope(snapshot.url,cfg.ScopeUrl,exclude))throw new Error('Navigation ausserhalb Scope wurde blockiert.');
        pages.push({Url:snapshot.url,Titel:snapshot.title,Formulare:snapshot.forms.length,Felder:snapshot.forms,Linkanzahl:snapshot.links.length});
        if(snapshot.passwords&&snapshot.url.startsWith('http:'))finding('Passwortfeld im HTTP-DOM','Hoch',snapshot.url,'Passwortfeld im gerenderten DOM erkannt.','Anmeldung ausschliesslich ueber HTTPS bereitstellen.');
        if(snapshot.mixed&&snapshot.url.startsWith('https:'))finding('Gemischte Ressourcen im DOM','Mittel',snapshot.url,`${snapshot.mixed} HTTP-src-Referenzen im HTTPS-DOM.`,'Alle aktiven Ressourcen ueber HTTPS laden.');
        for(const form of snapshot.forms){if(form.method.toLowerCase()==='get'&&form.fields.some(x=>x.type==='password'))finding('Passwortformular nutzt GET','Mittel',snapshot.url,'Passwortfeld in einem GET-Formular; Formular wurde nicht abgesendet.','Zugangsdaten im POST-Body ueber HTTPS uebertragen.');}
        for(const raw of snapshot.links){if(!inScope(raw,cfg.ScopeUrl,exclude))continue;const u=new URL(raw);u.hash='';if(item.depth<maxDepth&&seen.size<2000&&!seen.has(u.href)){seen.add(u.href);queue.push({url:u.href,depth:item.depth+1});}}
        const cookies=(await send('Network.getCookies',{urls:[snapshot.url]})).cookies;
        for(const c of cookies){if(!c.secure||!c.httpOnly)finding('Browser-Cookieattribute pruefen','Niedrig',snapshot.url,`Cookie ${c.name}: Secure=${c.secure}, HttpOnly=${c.httpOnly}. Kein Cookie-Wert gespeichert.`,'Attribute nach Verwendungszweck pruefen. JavaScript-Cookies koennen absichtlich ohne HttpOnly sein.');}
        if(cfg.Xss&&!cancelled){
          const base=new URL(snapshot.url);let probes=0;activeProbe=true;
          for(const key of new Set(base.searchParams.keys())){
            if(probes>=3||cancelled||allowed>=maxRequests)break;if(/token|secret|pass|auth|csrf|session|key|signature/i.test(key))continue;probes++;
            const marker='PW'+randomUUID().replaceAll('-',''),probe=new URL(base);
            probe.searchParams.set(key,`"><svg onload="window.__powerwebProbe='${marker}'">`);
            if(!inScope(probe.href,cfg.ScopeUrl,exclude))continue;
            try{await navigate(probe.href);if(!cancelled&&await evaluate(`window.__powerwebProbe === ${JSON.stringify(marker)}`))finding('XSS-Testcode im Browser ausgefuehrt','Hoch',base.href,`Parameter ${key}: eindeutiger Testmarker wurde durch den injizierten SVG-Handler gesetzt. Ein Payload-Kontext getestet.`,'Kontextgerechtes Ausgabe-Encoding und sichere DOM-APIs einsetzen; CSP ergaenzend verwenden.');}catch(e){if(warnings.length<20)warnings.push('XSS-Test nicht abgeschlossen: '+e.message);}
          }
          activeProbe=false;
        }
      }catch(e){navErrors++;history.push({ZeitpunktUtc:new Date().toISOString(),Methode:'GET',Url:item.url,Status:0,DauerMs:0,Typ:'Browser',Fehler:e.message});}
    }
    return {Findings:findings,History:history,Pages:pages,Summary:{Typ:'Browser',StartUtc:start,EndeUtc:new Date().toISOString(),Scope:cfg.ScopeUrl,Status:cancelled?'Abgebrochen':(navErrors?'Mit Fehlern':'Beendet'),Seiten:pages.length,Anfragen:allowed,Blockiert:blocked,Fehler:navErrors,RestQueue:queue.length,RequestLimitErreicht:allowed>=maxRequests,MaxSeiten:maxPages,MaxTiefe:maxDepth,Xss:!!cfg.Xss,Warnungen:warnings,Hinweis:'GET/HEAD, ohne Formularaktionen oder Klickfolgen. Fremde Ressourcen und Worker gesperrt; dies kann die Anwendung beeinflussen. Kein vollstaendiger Browser-Pentest.'}};
  }finally{
    if(cdp){try{await cdp.call('Browser.close');}catch{}}
    if(ws)ws.close();if(browser&&browser.exitCode===null){await wait(300);if(browser.exitCode===null)browser.kill();}
    // Delete only the uniquely-created disposable profile inside the OS temp folder.
    const resolved=path.resolve(profile);
    if(path.dirname(resolved)===tempRoot&&path.basename(resolved).startsWith('powerweb-browser-')){try{await rm(resolved,{recursive:true,force:true,maxRetries:8,retryDelay:200});}catch{}}
  }
}
if(path.resolve(process.argv[1]??'')===fileURLToPath(import.meta.url)){
  const lines=createInterface({input:process.stdin});
  lines.on('line',line=>{try{const data=JSON.parse(line);if(!config){config=data;run(config).then(r=>emit('result',r)).catch(e=>{emit('error',e.message);process.exitCode=1;}).finally(()=>{lines.close();process.stdin.destroy();});}else if(data.cancel)cancelled=true;}catch(e){emit('error','Ungueltige Steuerdaten.');process.exitCode=1;lines.close();process.stdin.destroy();}});
}
