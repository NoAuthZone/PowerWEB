# PowerWEB 3.2: Abfangender Proxy (Reiter 10)

Ein lokaler Forward-Proxy, mit dem sich HTTP-Anfragen abfangen und **Header (und
mehr) veraendern** lassen, bevor sie zum Ziel gehen – die Proxy-Grundfunktion aus
Burp/ZAP, eingebettet in das Scope- und Redaction-Modell von PowerWEB.

## Einrichten

1. In Reiter 1 den **Zielbereich** setzen (Regeln und Intercept gelten standardmaessig
   nur fuer diesen; andernfalls die Checkbox „Nur im Zielbereich" abwaehlen).
2. In Reiter 10 den **Port** waehlen (Standard 8081) und **Proxy starten**.
3. Im Browser einen **HTTP-Proxy** eintragen: Host `127.0.0.1`, Port wie eingestellt.
4. Traffic erscheint im Proxy-Verlauf. Zeile waehlen und **in Reiter 3 senden**, um
   eine Anfrage im Repeater/Anfrage-Editor weiter zu bearbeiten.

Der Proxy laeuft nur auf `127.0.0.1` (kein offener Netzdienst). Nur Ziele im
vereinbarten Testumfang verwenden.

## Header-Regeln (automatisch)

Eine Regel pro Zeile im Regelfeld; `#` ist ein Kommentar. Mit **Regeln / Optionen
uebernehmen** werden sie – auch im laufenden Betrieb – aktiv:

| Regel | Wirkung |
| --- | --- |
| `set Name: Wert` | Header setzen; vorhandene gleichnamige werden ersetzt, sonst hinzugefuegt |
| `add Name: Wert` | Header zusaetzlich anhaengen (Duplikat erlaubt) |
| `remove Name` | Header entfernen (Name ohne Wildcard = exakter, case-insensitiver Name) |
| `replace /regex/ersatz/` | .NET-Regex auf jede Headerzeile „Name: Wert" (nicht auf die Request-Zeile) |

Beispiele:

```
set X-Forwarded-For: 127.0.0.1
add Cookie: debug=1
remove Referer
replace /^User-Agent: .*/User-Agent: PowerWEB/
```

Regeln wirken auf die **Anfrage** an den Zielserver. Verbindungsverwaltete bzw.
hop-by-hop Header (Host, Content-Length, Connection, Proxy-Connection, Keep-Alive,
Transfer-Encoding, TE, Trailer, Upgrade, Proxy-Authorization) werden nicht
weitergereicht und nicht regelbar gesetzt.

## Manuelles Intercept

**Intercept an** haelt jede in-scope HTTP-Anfrage an. Die abgefangene Anfrage
(Request-Zeile + Header) erscheint editierbar im Reiter. Danach:

- **Weiterleiten** – der (ggf. editierte) Kopf wird geparst und gesendet.
- **Verwerfen** – die Anfrage wird nicht gesendet; der Client erhaelt `504`.

Automatische Regeln werden vor der Anzeige angewandt, sodass im Intercept bereits
der veraenderte Kopf steht. Mehrere gleichzeitig abgefangene Anfragen werden nacheinander
angezeigt.

## HTTPS und Grenzen

- **HTTPS (CONNECT) wird nur getunnelt**, nicht aufgebrochen. Header innerhalb von
  HTTPS koennen in dieser Stufe **nicht** veraendert werden. Echtes HTTPS-Intercept
  erfordert eine eigene CA (MITM) und ist als naechster Schritt vorgesehen.
- Der Proxy nutzt **`Connection: close`** je Antwort (keine Keep-Alive-Wiederverwendung
  zum Client) und einen Runspace-Pool (bis 32 parallele Verbindungen). Sehr viele
  gleichzeitige HTTPS-Tunnel koennen die Grenze erreichen.
- Der **Proxy-Verlauf bleibt nur im Arbeitsspeicher** und wird nicht ins Projekt
  gespeichert. In der Anzeige werden bekannte Anmelde-Header (Authorization, Cookie)
  maskiert; die vollstaendigen Werte bleiben nur fuer „in Reiter 3 senden" im Speicher.
- Weiterleitung folgt keinen Redirects automatisch und dekomprimiert nicht; der
  Antwortkoerper wird unveraendert an den Client zurueckgegeben.

## Lokale Validierung

`tests/Test-Proxy.ps1` startet Origin und Proxy lokal und prueft Weiterleitung,
alle Regeltypen, Scope-Gating, Live-Regeln und das Intercept (Forward mit Edit +
Drop):

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Test-Proxy.ps1
```
