# PowerWEB 3.2: Intruder (Reiter 9)

Der Intruder sendet wiederholte, gezielt veraenderte HTTP-Anfragen mit eigenen
Testwerten – vergleichbar mit dem Intruder-Werkzeug anderer Suiten, aber im
Sicherheitsmodell von PowerWEB: alles laeuft ueber dieselbe HTTP-Schicht mit
Zielbereichs-Pruefung, Header-Regeln, Limits, Abbruch und Maskierung.

## Positionen markieren

Positionen werden mit einem **Paar Paragraphzeichen** (`§…§`) markiert. Der Text
zwischen den Marken ist der Basiswert und wird im Angriff durch Payloads ersetzt.
Marken sind in drei Feldern erlaubt und werden in dieser Reihenfolge nummeriert:

1. **URL** (`IntruderUrl`)
2. **Zusaetzliche Header** (`IntruderHeaders`, je Zeile `Name: Wert`)
3. **Body** (`IntruderBody`)

Beispiel URL: `https://ziel/app/suche?q=§base§&seite=§1§`
– Position 1 = `q`, Position 2 = `seite`.

Mit **„Aus Reiter 3"** lassen sich Methode, URL, Header und Body aus dem
Anfrage-Editor uebernehmen und dann markieren.

## Angriffsmodi

| Modus | Payload-Sets | Verhalten | Anfragen |
| --- | --- | --- | --- |
| **Sniper** | Set 1 | Ersetzt eine Position nach der anderen, andere Positionen behalten ihren Basiswert | Positionen × Werte |
| **Battering ram** | Set 1 | Setzt denselben Wert gleichzeitig in alle Positionen | Werte |
| **Pitchfork** | je Position ein Set | Werte im Gleichschritt (Set 1 → Pos 1, Set 2 → Pos 2 …) | Laenge des kuerzesten Sets |
| **Cluster bomb** | je Position ein Set | Alle Kombinationen (kartesisches Produkt) | Produkt der Set-Laengen |

Set 1 gilt fuer Sniper und Battering ram. Fuer Pitchfork und Cluster bomb wird
Set N der Position N zugeordnet; es muessen mindestens so viele nicht-leere Sets
wie Positionen vorhanden sein.

## Grenzen und Schutz

- Jede erzeugte URL wird gegen **Zielbereich und Ausschluesse** geprueft
  (Reiter 1). Ausserhalb liegende Kombinationen werden ohne Netzwerkanfrage als
  „Ausserhalb Zielbereich" protokolliert.
- Verbindungsverwaltete Header (Host, Content-Length, Connection …) bleiben
  gesperrt; **CR/LF in Headerwerten** werden abgelehnt. Fuer Header-Injektionstests
  die Regel `PW-CRLF` der eigenen Engine (Reiter 8) verwenden.
- **Aendernde Methoden** (POST/PUT/PATCH/DELETE) erfordern die Freigabe-Checkbox;
  sie wird nach dem Start zurueckgesetzt.
- **Max. Anfragen** 1–5000 begrenzt jeden Lauf (Cluster bomb wird bei Erreichen
  gestoppt und als „Limit erreicht" gemeldet). Bis zu **8 Positionen**, je Payload
  maximal 2048 Zeichen, je Set maximal 1000 Werte.
- Pause und Timeout kommen aus Reiter 1. Die aktive **Sitzung A/B** (Cookies) und
  die Anmelde-Header gelten wie bei manuellen Anfragen; eigene Header ueberschreiben
  gleichnamige Anmelde-Header.
- Optional werden Payloads im **URL-Teil URL-kodiert** (Standard an). Header- und
  Body-Positionen werden woertlich eingesetzt.

## Ergebnisse

Die Tabelle zeigt je Anfrage: Nummer, Position(en) (1-basiert), Payload, HTTP-Status,
Headerzeit (ms), gelesene Bytes, Kuerzung, **woertliche Reflexion** und Fehler sowie
die maskierte URL. Anfragen erscheinen zusaetzlich im Verlauf (Reiter 5), die
Laufzusammenfassung im Bericht.

**Reflexion ist kein Ausnutzbarkeitsnachweis.** Sie zeigt nur, dass der Payload
woertlich im Antworttext vorkommt; Ausgabekontext, Encoding und Browserwirkung sind
manuell zu bewerten. Bekannte Anmelde-Geheimnisse werden in Ergebnissen und Verlauf
nach Moeglichkeit maskiert; Payloads und URLs koennen dennoch vertraulich sein –
Berichte vor Weitergabe pruefen.

## Lokale Validierung

`tests/Test-Intruder.ps1` startet einen Loopback-Testserver und prueft Anfragezahl
je Modus, Reflexionserkennung, das Anfrage-Limit, Scope/Ausschluss und die Freigabe
fuer aendernde Methoden:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Test-Intruder.ps1
```
