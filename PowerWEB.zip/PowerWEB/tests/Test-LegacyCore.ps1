﻿# SPDX-License-Identifier: MIT
[CmdletBinding()]
param([string]$ArtifactDirectory=$env:TEMP)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'PowerWEB.Core.psm1') -Force
function Assert($Condition,$Message) { if (-not $Condition) { throw $Message } }
foreach ($file in Get-ChildItem $root -Include *.ps1,*.psm1 -Recurse) {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    Assert ($errors.Count -eq 0) ($errors | Out-String)
}
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
$listener.Start()
$port=$listener.LocalEndpoint.Port
$server=[PowerShell]::Create()
[void]$server.AddScript({param($listener)
    for ($i=0; $i -lt 3; $i++) {
        $client=$listener.AcceptTcpClient()
        try {
            $stream=$client.GetStream()
            $reader=[IO.StreamReader]::new($stream)
            $line=$reader.ReadLine()
            while ($reader.ReadLine()) {}
            $status = if ($line -match '/redirect ') { '302 Found' } elseif ($line -match '/missing ') { '404 Not Found' } else { '200 OK' }
            $message="HTTP/1.1 $status`r`nContent-Length: 0`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`nContent-Security-Policy: default-src 'self'; frame-ancestors 'none'`r`nSet-Cookie: session=TOPSECRET; Secure; HttpOnly; SameSite=Lax`r`nSet-Cookie: weak=HIDDEN; Path=/`r`nLocation: http://127.0.0.1:1/do-not-follow`r`n`r`n"
            $bytes=[Text.Encoding]::ASCII.GetBytes($message)
            $stream.Write($bytes,0,$bytes.Length)
        } finally { $client.Close() }
    }
}).AddArgument($listener)
$handle=$server.BeginInvoke()
try {
    $report=Invoke-PowerWebCheck -Url "http://127.0.0.1:$port/"
    Assert ($report.HttpStatus -eq 200) 'Expected HTTP 200'
    Assert (@($report.Ergebnisse | Where-Object { $_.Bereich -eq 'Cookie: session' -and $_.Status -eq 'OK' }).Count -eq 1) 'Secure cookie check failed'
    Assert (@($report.Ergebnisse | Where-Object { $_.Bereich -eq 'Cookie: weak' -and $_.Status -eq 'Review' }).Count -eq 1) 'Weak cookie check failed'
    $json=$report | ConvertTo-Json -Depth 8
    Assert ($json -notmatch 'TOPSECRET|HIDDEN') 'Cookie value leak'
    Assert ((Invoke-PowerWebCheck -Url "http://127.0.0.1:$port/redirect").HttpStatus -eq 302) 'Redirect followed'
    Assert ((Invoke-PowerWebCheck -Url "http://127.0.0.1:$port/missing").HttpStatus -eq 404) 'Error response not analysed'
    [void]$server.EndInvoke($handle)
    foreach ($url in @('file:///C:/Windows','not-a-url','https://user:password@example.org')) {
        $rejected=$false
        try { Invoke-PowerWebCheck -Url $url } catch { $rejected=$true }
        Assert $rejected "Invalid URL accepted: $url"
    }
    $report.Url='<script>alert(1)</script>'
    $html=Join-Path $ArtifactDirectory 'legacy-test-report.html'
    Export-PowerWebReport -Report $report -Path $html
    $saved=[IO.File]::ReadAllText($html)
    Assert ($saved -notmatch '<script>') 'HTML injection'
    Assert ($saved -match '&lt;script&gt;') 'HTML encoding missing'
    $jsonPath=Join-Path $ArtifactDirectory 'legacy-test-report.json'
    Export-PowerWebReport -Report $report -Path $jsonPath -Format JSON
    Assert (((Get-Content $jsonPath -Raw | ConvertFrom-Json).HttpStatus) -eq 200) 'JSON round trip failed'
    'PASS: legacy CLI syntax, HTTP 200/302/404, cookies, secret omission, invalid URLs and report encoding.'
} finally { $listener.Stop(); $server.Dispose() }
