# SPDX-License-Identifier: MIT
# Lokaler Funktionstest fuer den PowerWEB-Proxy. Startet einen Loopback-Origin,
# den Proxy in einem Hintergrund-Runspace und schickt Anfragen durch den Proxy.
# Prueft Weiterleitung, Header-Regeln (set/add/remove/replace), Scope-Gating,
# Live-Regeln und manuelles Intercept (Forward mit Edit + Drop). Kein externes Ziel.
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$mod=Join-Path $root 'PowerWEB.Proxy.psm1'
Import-Module $mod -Force
function Assert($c,$m){ if(-not $c){ throw "FAIL: $m" } }

$origin=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $origin.Start(); $oport=$origin.LocalEndpoint.Port
$osrv=[PowerShell]::Create()
[void]$osrv.AddScript({ param($listener)
    while($true){ if(-not $listener.Pending()){ Start-Sleep -Milliseconds 5; continue }
        $c=$listener.AcceptTcpClient()
        try{ $s=$c.GetStream(); $s.ReadTimeout=3000; $sr=[IO.StreamReader]::new($s)
            $lines=@(); while(($l=$sr.ReadLine())){ $lines+=$l }
            $b=[Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))
            $h=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/plain`r`nContent-Length: $($b.Length)`r`nConnection: close`r`n`r`n")
            $s.Write($h,0,$h.Length); $s.Write($b,0,$b.Length)
        }catch{}finally{$c.Close()} }
}).AddArgument($origin)
[void]$osrv.BeginInvoke()

$scope="http://127.0.0.1:$oport/"
$probe=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $probe.Start(); $pport=$probe.LocalEndpoint.Port; $probe.Stop()
$state=New-PWProxyState -Port $pport -ScopeUrl $scope -RulesText "set X-PW-Test: injected`nremove User-Agent`nreplace /^Accept: .*/Accept: text/pw/" -InterceptOn:$false -RulesInScopeOnly:$true
$psrv=[PowerShell]::Create()
[void]$psrv.AddScript({ param($module,$st) Import-Module $module -Force; Start-PWProxyServer -State $st -ModulePath $module }).AddArgument($mod).AddArgument($state)
[void]$psrv.BeginInvoke()
for($i=0;$i -lt 50 -and -not $state.Listening;$i++){ Start-Sleep -Milliseconds 100 }
Assert $state.Listening ("Proxy lauscht nicht: "+$state.Error)

function Send-ThroughProxy($absUrl){
    $c=[Net.Sockets.TcpClient]::new('127.0.0.1',$pport); $s=$c.GetStream(); $s.ReadTimeout=6000
    $req="GET $absUrl HTTP/1.1`r`nHost: 127.0.0.1:$oport`r`nUser-Agent: ClientUA`r`nAccept: application/json`r`nConnection: close`r`n`r`n"
    $rb=[Text.Encoding]::ASCII.GetBytes($req); $s.Write($rb,0,$rb.Length); $s.Flush()
    $ms=[IO.MemoryStream]::new(); $buf=New-Object byte[] 4096
    try{ while(($n=$s.Read($buf,0,$buf.Length)) -gt 0){ $ms.Write($buf,0,$n) } }catch{}
    $c.Close(); [Text.Encoding]::UTF8.GetString($ms.ToArray())
}
function Start-Client(){
    $ps=[PowerShell]::Create()
    [void]$ps.AddScript({ param($port,$oport,$scope)
        $c=[Net.Sockets.TcpClient]::new('127.0.0.1',$port); $s=$c.GetStream(); $s.ReadTimeout=8000
        $req="GET ${scope}secret HTTP/1.1`r`nHost: 127.0.0.1:$oport`r`nConnection: close`r`n`r`n"
        $rb=[Text.Encoding]::ASCII.GetBytes($req); $s.Write($rb,0,$rb.Length); $s.Flush()
        $ms=[IO.MemoryStream]::new(); $buf=New-Object byte[] 4096
        try{ while(($n=$s.Read($buf,0,$buf.Length)) -gt 0){ $ms.Write($buf,0,$n) } }catch{}
        $c.Close(); [Text.Encoding]::UTF8.GetString($ms.ToArray())
    }).AddArgument($pport).AddArgument($oport).AddArgument($scope)
    @{ PS=$ps; Handle=$ps.BeginInvoke() }
}

# 1) In-Scope: Regeln greifen
$resp=Send-ThroughProxy "${scope}echo"
Assert ($resp -match '200 OK') "Antwortstatus fehlt"
Assert ($resp -match 'X-PW-Test: injected') "set-Regel nicht angewandt"
Assert ($resp -notmatch 'User-Agent: ClientUA') "remove-Regel nicht angewandt"
Assert ($resp -match 'Accept: text/pw') "replace-Regel nicht angewandt"
Assert ($state.History.Count -ge 1 -and $state.History[$state.History.Count-1].Veraendert) "History/Veraendert falsch"

# 2) Out-of-scope: keine Regeln
$state.ScopeUrl="http://example.invalid/"
$resp2=Send-ThroughProxy "http://127.0.0.1:$oport/echo2"
Assert ($resp2 -match 'User-Agent: ClientUA') "Out-of-scope: UA sollte bleiben"
Assert ($resp2 -notmatch 'X-PW-Test') "Out-of-scope: keine Regel erwartet"

# 3) Live-Regeln
$state.ScopeUrl=$scope; $state.Rules=@(ConvertFrom-PWProxyRules "set X-Live: yes")
$resp3=Send-ThroughProxy "${scope}echo3"
Assert ($resp3 -match 'X-Live: yes') "Live-Regel nicht aktiv"

# 4) Intercept: Forward mit Edit
$state.Rules=@(); $state.InterceptOn=$true
$client=Start-Client
for($i=0;$i -lt 60 -and $state.Pending.Count -lt 1;$i++){ Start-Sleep -Milliseconds 100 }
Assert ($state.Pending.Count -ge 1) "Keine abgefangene Anfrage"
$item=$state.Pending.Dequeue()
Assert ($item.Raw -match 'GET http://') "Rohanfrage unerwartet"
$item.Edited=$item.Raw.TrimEnd()+"`r`nX-Intercept: edited"; $item.Decision='forward'; $item.Done=$true
$r4=$client.PS.EndInvoke($client.Handle)[0]; $client.PS.Dispose()
Assert ($r4 -match 'X-Intercept: edited') "Editierter Header kam nicht an"

# 5) Intercept: Drop
$client=Start-Client
for($i=0;$i -lt 60 -and $state.Pending.Count -lt 1;$i++){ Start-Sleep -Milliseconds 100 }
Assert ($state.Pending.Count -ge 1) "Keine zweite abgefangene Anfrage"
$item=$state.Pending.Dequeue(); $item.Decision='drop'; $item.Done=$true
$r5=$client.PS.EndInvoke($client.Handle)[0]; $client.PS.Dispose()
Assert ($r5 -match '504') "Drop lieferte kein 504"

Write-Host 'PASS: Test-Proxy (Forward, set/add/remove/replace, Scope, Live-Regeln, Intercept Forward+Drop)' -ForegroundColor Green
$state.Stop=$true; Start-Sleep -Milliseconds 200
try{ $psrv.Stop() }catch{}; $psrv.Dispose(); try{ $origin.Stop() }catch{}; try{ $osrv.Stop() }catch{}; $osrv.Dispose()
