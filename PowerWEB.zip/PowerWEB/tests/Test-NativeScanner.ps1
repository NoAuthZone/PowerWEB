﻿# SPDX-License-Identifier: MIT
# Local controlled positive/negative fixtures, no external services or database.
[CmdletBinding()]
param([string]$ArtifactDirectory=$env:TEMP)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'PowerWEB.Scanner.psm1') -Force
Import-Module (Join-Path $root 'PowerWEB.Audit.psm1') -Force
function Assert($Condition,$Message){if(-not $Condition){throw $Message}}
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$listener.Start();$port=$listener.LocalEndpoint.Port
$scope="http://127.0.0.1:$port/app/"
$fixture=[hashtable]::Synchronized(@{Stop=$false;Seen=[Collections.ArrayList]::Synchronized([Collections.ArrayList]::new())})
$server=[PowerShell]::Create()
[void]$server.AddScript({param($listener,$fixture)
    while(-not $fixture.Stop){
        if(-not $listener.Pending()){Start-Sleep -Milliseconds 5;continue}
        $client=$listener.AcceptTcpClient()
        try{
            $stream=$client.GetStream();$stream.ReadTimeout=3000;$reader=[IO.StreamReader]::new($stream)
            $line=$reader.ReadLine();if(-not $line){continue};$parts=$line.Split(' ');$uri=[Uri]('http://localhost'+$parts[1]);$headers=@{}
            while($line=$reader.ReadLine()){$pair=$line -split ':',2;$headers[$pair[0]]=$pair[1].Trim()}
            if($headers['Expect'] -eq '100-continue'){$interim=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 100 Continue`r`n`r`n");$stream.Write($interim,0,$interim.Length)}
            $bodyIn='';if($headers['Content-Length']){for($i=0;$i -lt [int]$headers['Content-Length'];$i++){$bodyIn += [char]$reader.Read()}}
            $query=@{};foreach($part in $uri.Query.TrimStart('?').Split('&')){if($part){$p=$part -split '=',2;$query[[Uri]::UnescapeDataString($p[0])]=if($p.Count -gt 1){[Uri]::UnescapeDataString($p[1])}else{''}}}
            [void]$fixture.Seen.Add([pscustomobject]@{Path=$uri.AbsolutePath;Method=$parts[0];Query=$query;Cookie=$headers['Cookie']})
            $value=if($query.ContainsKey('q')){$query.q}elseif($query.ContainsKey('id')){$query.id}elseif($query.ContainsKey('next')){$query.next}else{''}
            $status='200 OK';$extra='';$body='BASE';$contentType='text/html; charset=utf-8'
            switch($uri.AbsolutePath){
                '/app/error'{if($value.EndsWith("'") -and -not $value.EndsWith("''")){$body='You have an error in your SQL syntax';$status='500 Internal Server Error'}}
                '/app/boolean'{$body='ROW';if($value -match 'AND (\d+)=(\d+)' -and $Matches[1] -ne $Matches[2]){$body='NO ROWS'}}
                '/app/dynamic'{$body=[Guid]::NewGuid().ToString()}
                '/app/template'{$body=[regex]::Replace($value,'\{\{(\d+)\*(\d+)\}\}',[Text.RegularExpressions.MatchEvaluator]{param($m)([int]$m.Groups[1].Value*[int]$m.Groups[2].Value).ToString()})}
                '/app/reflect'{$body=$value+' TOPSECRET00001'}
                '/app/safe'{$body=[Net.WebUtility]::HtmlEncode($value)}
                '/app/large'{$body='X'*270000}
                '/app/large-probe'{if($value -ne '1'){$body='X'*270000}}
                '/app/binary'{$contentType='application/octet-stream';$body='BINARY'}
                '/app/redirect'{if($value.StartsWith('https://')){$status='302 Found';$extra="Location: $value`r`n"}}
                '/app/header'{if($value.Contains("`r`n")){$extra='X-Original: '+$value+"`r`n"}}
                '/app/cors'{if($headers['Origin']){$extra='Access-Control-Allow-Origin: '+$headers['Origin']+"`r`nAccess-Control-Allow-Credentials: true`r`n"}}
                '/app/cors-fixed'{$extra="Access-Control-Allow-Origin: https://fixed.invalid`r`nAccess-Control-Allow-Credentials: true`r`n"}
                '/app/login'{if($bodyIn -eq 'role=A'){$extra="Set-Cookie: PWSESSION=ROLE_A_PRIVATE; Path=/app/; HttpOnly`r`n"}else{$extra="Set-Cookie: PWSESSION=ROLE_B_PRIVATE; Path=/app/; HttpOnly`r`n"}}
                '/app/account'{if($headers['Cookie'] -match 'ROLE_A_PRIVATE'){$body='ROLE A DATA'}elseif($headers['Cookie'] -match 'ROLE_B_PRIVATE'){$body='ROLE B DATA'}else{$status='401 Unauthorized';$body='LOGIN REQUIRED'}}
                '/app/'{$body='<a href="/app/safe?q=1">safe</a><a href="/outside">outside</a><a href="/app/logout">logout</a>'}
            }
            $bytes=[Text.Encoding]::UTF8.GetBytes($body)
            $head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $contentType`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n${extra}`r`n")
            $stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length)
        }catch{}finally{$client.Close()}
    }
}).AddArgument($listener).AddArgument($fixture)
$handle=$server.BeginInvoke()
try{
    $cases=@(@('error?q=1','PW-SQL-ERROR'),@('boolean?id=1','PW-SQL-BOOL'),@('template?q=base','PW-TEMPLATE'),@('reflect?q=base&access_token=TOPSECRET00001','PW-HTML'),@('redirect?next=home','PW-REDIRECT'),@('header?q=base','PW-CRLF'),@('cors','PW-CORS'))
    $allFindings=@();$allRuns=@()
    foreach($case in $cases){
        $r=Invoke-PWNativeScan -ScopeUrl ($scope+$case[0]) -MaxDepth 0 -DelayMs 0 -Rules @($case[1]) -Headers @{Authorization='Bearer AUTH_PRIVATE00001'}
        $hits=@($r.Findings | Where-Object {$_.PSObject.Properties.Name -contains 'RegelId' -and $_.RegelId -eq $case[1]})
        Assert ($hits.Count -eq 1) ("Missing positive {0}: {1}" -f $case[1],($r|ConvertTo-Json -Depth 8))
        Assert ($hits[0].Belege.Count -ge 2 -and $hits[0].Belege[0].TextSHA256.Length -eq 64) 'Missing structured evidence'
        Assert (($r|ConvertTo-Json -Depth 12) -notmatch 'AUTH_PRIVATE00001|TOPSECRET00001') 'Secret leaked in native evidence'
        Assert ($r.Summary.Fehler -eq 0) 'Unexpected request error'
        $allFindings+=@($r.Findings);$allRuns+=@($r.Summary)
    }
    $safe=Invoke-PWNativeScan -ScopeUrl ($scope+'safe?q=1') -MaxDepth 0 -DelayMs 0
    Assert (@($safe.Findings | Where-Object Quelle -eq 'Native engine').Count -eq 0) 'False positive on escaped/reflecting safe fixture'
    $dynamic=Invoke-PWNativeScan -ScopeUrl ($scope+'dynamic?id=1') -MaxDepth 0 -DelayMs 0 -Rules @('PW-SQL-BOOL')
    Assert (@($dynamic.Tests|Where-Object Ergebnis -like 'Skipped*').Count -eq 1 -and $dynamic.Tests.Count -eq 1) 'Dynamic baseline not skipped cleanly'
    $fixed=Invoke-PWNativeScan -ScopeUrl ($scope+'cors-fixed') -MaxDepth 0 -DelayMs 0 -Rules @('PW-CORS')
    Assert (@($fixed.Findings|Where-Object Quelle -eq 'Native engine').Count -eq 0) 'Fixed CORS false positive'
    $limited=Invoke-PWNativeScan -ScopeUrl ($scope+'boolean?id=1') -MaxRequests 2 -MaxDepth 0 -DelayMs 0 -Rules @('PW-SQL-BOOL')
    Assert ($limited.Summary.Anfragen -eq 2 -and $limited.Summary.Status -eq 'Limit reached' -and @($limited.Findings|Where-Object Quelle -eq 'Native engine').Count -eq 0) 'Budget yielded a false clean/positive result'
    $crawl=Invoke-PWNativeScan -ScopeUrl $scope -MaxPages 2 -MaxDepth 1 -DelayMs 0 -Rules @('PW-HTML')
    Assert ($crawl.Summary.Seiten -eq 2 -and @($fixture.Seen|Where-Object {$_.Path -eq '/outside' -or $_.Path -eq '/app/logout'}).Count -eq 0) 'Native crawl escaped scope/exclusions'
    $pageLimited=Invoke-PWNativeScan -ScopeUrl $scope -MaxPages 1 -MaxDepth 1 -DelayMs 0 -Rules @('PW-HTML')
    Assert ($pageLimited.Summary.Status -eq 'Limit reached' -and $pageLimited.Summary.RestQueue -gt 0) 'Page limit not reported'
    $cancelled=Invoke-PWNativeScan -ScopeUrl $scope -Control @{Cancel=$true;Request=$null;Message=''}
    Assert ($cancelled.Summary.Status -eq 'Cancelled' -and $cancelled.Summary.Anfragen -eq 0) 'Pre-cancel sent requests'
    foreach($endpoint in @('large','binary')) {
        $partial=Invoke-PWNativeScan -ScopeUrl ($scope+$endpoint+'?q=1') -MaxDepth 0 -DelayMs 0 -Rules @('PW-HTML')
        Assert ($partial.Tests.Count -eq 1 -and $partial.Tests[0].Ergebnis -like 'Skipped*') 'Unread/incomplete baseline treated as completed'
        $comparison=Invoke-PWRoleComparison -Url ($scope+$endpoint) -ScopeUrl $scope
        Assert (-not $comparison.TextVergleichbar -and $null -eq $comparison.TextGleich) 'Partial/binary responses declared equal'
    }
    $partial=Invoke-PWNativeScan -ScopeUrl ($scope+'large-probe?q=1') -MaxDepth 0 -DelayMs 0 -Rules @('PW-HTML')
    Assert ($partial.Tests[0].Ergebnis -eq 'Incomplete' -and $partial.Summary.Status -eq 'Some checks incomplete') 'Truncated probe reported as completed negative'
    $a=[Net.CookieContainer]::new();$b=[Net.CookieContainer]::new()
    $null=Invoke-PWHttp -Url ($scope+'login') -ScopeUrl $scope -Method POST -Body 'role=A' -CookieContainer $a
    $null=Invoke-PWHttp -Url ($scope+'login') -ScopeUrl $scope -Method POST -Body 'role=B' -CookieContainer $b
    $roles=Invoke-PWRoleComparison -Url ($scope+'account') -ScopeUrl $scope -CookiesA $a -CookiesB $b
    Assert ($roles.StatusA -eq 200 -and $roles.StatusB -eq 200 -and -not $roles.TextGleich) 'Sessions not retained/isolated'
    Assert (($roles|ConvertTo-Json) -notmatch 'ROLE_A_PRIVATE|ROLE_B_PRIVATE') 'Role cookie leaked'
    $anonymous=Invoke-PWHttp -Url ($scope+'account') -ScopeUrl $scope -CookieContainer ([Net.CookieContainer]::new())
    Assert ($anonymous.Status -eq 401) 'Unexpected anonymous authentication'
    $project=New-PWProject -Name 'Native scanner fixture' -ScopeUrl $scope;$project.Findings=$allFindings;$project.Runs=$allRuns
    Save-PWProject $project (Join-Path $ArtifactDirectory 'native-test.json')
    $loaded=Import-PWProject (Join-Path $ArtifactDirectory 'native-test.json')
    Assert (@($loaded.Findings|Where-Object {$_.PSObject.Properties.Name -contains 'Belege'}).Count -eq 7) 'Evidence round trip failed'
    Export-PWProjectReport $project (Join-Path $ArtifactDirectory 'native-test.html')
    $html=Get-Content (Join-Path $ArtifactDirectory 'native-test.html') -Raw
    Assert ($html.Contains('Control requests and response evidence') -and $html.Contains('Ausschnitt') -and -not $html.Contains('<pw-probe')) 'HTML evidence omitted or not escaped'
    Export-PWProjectReport $project (Join-Path $ArtifactDirectory 'native-test.csv') CSV
    $csv=@(Import-Csv (Join-Path $ArtifactDirectory 'native-test.csv'))
    Assert (@($csv|Where-Object {$_.RegelId -and $_.Belege -match 'TextSHA256'}).Count -eq 7) 'Mixed finding CSV lost structured evidence'
    'PASS: seven rule positive fixtures, safe/dynamic/fixed-CORS negatives, evidence and redaction, hard request budget, scope, two cookie sessions, anonymous negative and evidence project round trip.'
    . (Join-Path $root 'PowerWEB.Workbench.ps1') -NoShow
    function Click([string]$Name){$controls[$Name].RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent))}
    function Wait-UI {
        $until=[DateTime]::UtcNow.AddSeconds(20)
        while($state.Worker -and [DateTime]::UtcNow -lt $until){$window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);Start-Sleep -Milliseconds 20}
        Assert ($null -eq $state.Worker) 'Native GUI worker timeout'
        Assert (-not $controls.Status.Text.StartsWith('Fehler:')) $controls.Status.Text
    }
    $controls.Scope.Text=$scope+'reflect?q=base';$controls.Delay.Text='0';$controls.MaxDepth.Text='0'
    foreach($name in @('NativeSqlError','NativeSqlBool','NativeTemplate','NativeRedirect','NativeCrlf','NativeCors')){$controls[$name].IsChecked=$false}
    $controls.NativeAuthorize.IsChecked=$true;Click 'NativeStart';Wait-UI
    Assert (@($state.Project.Findings|Where-Object Quelle -eq 'Native engine').Count -eq 1 -and $controls.NativeResults.Items.Count -eq 1) 'Native GUI scan/results failed'
    $controls.Scope.Text=$scope;$controls.RequestUrl.Text=$scope+'login';$controls.Method.SelectedItem='POST';$controls.RequestBody.Text='role=A';$controls.AllowWrite.IsChecked=$true;Click 'Send';Wait-UI
    Assert ($state.Sessions.A.Cookies.Count -eq 1) 'GUI login did not retain A cookie'
    $controls.SessionChoice.SelectedItem='B';$controls.RequestBody.Text='role=B';$controls.AllowWrite.IsChecked=$true;Click 'Send';Wait-UI
    Assert ($state.Sessions.B.Cookies.Count -eq 1) 'GUI login did not retain B cookie'
    $controls.RoleUrl.Text=$scope+'account';Click 'RoleCompare';Wait-UI
    $roleResult=$state.Project.Runs[-1].Ergebnis
    Assert ($roleResult.StatusA -eq 200 -and $roleResult.StatusB -eq 200 -and -not $roleResult.TextGleich) 'GUI role comparison failed'
    Click 'SessionClear';Click 'RoleCompare';Wait-UI
    Assert ($state.Project.Runs[-1].Ergebnis.StatusB -eq 401) 'GUI session reset failed'
    Assert ($state.Sessions.A.Origin -and $state.Sessions.B.Origin -eq $state.Sessions.A.Origin) 'Role comparison did not bind both sessions'
    $previousScope=$controls.Scope.Text;$controls.Scope.Text='http://127.0.0.1:1/app/'
    Click 'RoleCompare'
    Assert ($controls.Status.Text.StartsWith('Fehler:') -and -not $state.Worker) 'Session reused across origins'
    $controls.Scope.Text=$previousScope
    Sync-Project
    Assert (($state.Project | ConvertTo-Json -Depth 12) -notmatch 'ROLE_A_PRIVATE|ROLE_B_PRIVATE') 'Session secret in project'
    $controls.Tabs.SelectedIndex=7;$window.Show();$window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::ApplicationIdle);$window.UpdateLayout()
    $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new([int]$window.ActualWidth,[int]$window.ActualHeight,96,96,[Windows.Media.PixelFormats]::Pbgra32);$bitmap.Render($window)
    $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
    $imageFile=[IO.File]::Create((Join-Path $ArtifactDirectory 'native-gui.png'));try{$encoder.Save($imageFile)}finally{$imageFile.Dispose()}
    $controls.NativePages.Text='49';$controls.NativeHtml.IsChecked=$false;$controls.BrowserXss.IsChecked=$true
    Clear-PrivateState;$state.Project=New-PWProject;Refresh-Project
    Assert ($controls.NativePages.Text -eq '10' -and $controls.NativeHtml.IsChecked -and -not $controls.BrowserXss.IsChecked) 'New project inherited previous scan settings'
    Assert ($state.Sessions.A.Cookies.Count -eq 0 -and $state.Sessions.B.Cookies.Count -eq 0) 'New project retained sessions'
    $state.Dirty=$false;$window.Close()
    'PASS: native GUI scan, proof table, two POST logins, A/B switching and comparison, session reset and project secret omission.'
}finally{$fixture.Stop=$true;$listener.Stop();if(-not $handle.IsCompleted){$server.Stop()};$server.Dispose()}
