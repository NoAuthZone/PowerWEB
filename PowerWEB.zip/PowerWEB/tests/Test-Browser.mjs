// SPDX-License-Identifier: MIT
import http from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const browser=process.argv[2];if(!browser)throw new Error('Pass the path to msedge.exe or chrome.exe.');
const seen=[];
const server=http.createServer((req,res)=>{
  seen.push({url:req.url,method:req.method,auth:req.headers.authorization});
  const u=new URL(req.url,'http://localhost');res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Set-Cookie','test=PRIVATE_COOKIE; HttpOnly; SameSite=Lax');
  let body='<h1>Test fixture</h1>';
  if(u.pathname==='/app/')body+=`<script>setTimeout(()=>{const a=document.createElement('a');a.href='/app/dynamic';a.textContent='dynamic';document.body.append(a)},100);fetch('/app/state',{method:'POST'}).catch(()=>{});</script><a href="/app/unsafe?q=hello">unsafe</a><a href="/app/safe?q=hello">safe</a><a href="/outside">outside</a><a href="/app/logout">logout</a><script src="/outside-script"></script><form method="get"><input type="password" name="password"></form>`;
  if(u.pathname==='/app/unsafe')body+=u.searchParams.get('q')??'';
  if(u.pathname==='/app/safe')body+=(u.searchParams.get('q')??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
  if(u.pathname==='/app/dynamic')body+='<script>throw new Error("fixture JS error")</script>';
  res.end(body);
});
server.listen(0,'127.0.0.1');await once(server,'listening');
const scope=`http://127.0.0.1:${server.address().port}/app/`;
const runner=fileURLToPath(new URL('../browser/powerweb-browser.mjs',import.meta.url));
try{
  const child=spawn(process.execPath,[runner],{windowsHide:true,stdio:['pipe','pipe','pipe']});
  let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
  child.stdin.write(JSON.stringify({ScopeUrl:scope,BrowserPath:browser,Exclude:['logout'],Headers:{Authorization:'Bearer TEST_ONLY'},MaxPages:5,MaxDepth:2,TimeoutSeconds:10,SettleMs:350,MaxRequests:100,Xss:true})+'\n');
  const timeout=setTimeout(()=>{child.kill();},60000);
  const [code]=await once(child,'exit');clearTimeout(timeout);
  assert.equal(code,0,stdout+'\n'+stderr);
  const messages=stdout.trim().split(/\r?\n/).map(x=>JSON.parse(x));
  const r=messages.find(x=>x.type==='result')?.data;assert.ok(r,stdout);
  assert.equal(r.Summary.Fehler,0,JSON.stringify(r.Summary));
  assert.ok(r.Pages.some(p=>p.Url.endsWith('/dynamic')),'JS-generated link not discovered');
  assert.ok(r.Findings.some(f=>f.Titel==='XSS-Testcode im Browser ausgefuehrt'&&f.Url.includes('/unsafe')),'Vulnerable fixture not found');
  assert.ok(!r.Findings.some(f=>f.Titel==='XSS-Testcode im Browser ausgefuehrt'&&f.Url.includes('/safe')),'False XSS on escaped fixture');
  assert.ok(r.Findings.some(f=>f.Titel==='Passwortformular nutzt GET'),'GET password form missing');
  assert.ok(r.Findings.some(f=>f.Titel==='JavaScript-Laufzeitfehler'),'Browser error missing');
  assert.ok(!seen.some(x=>x.url.startsWith('/outside')||x.url.includes('logout')||x.method==='POST'),'Scope/read-only boundary violated');
  assert.ok(seen.filter(x=>x.url.startsWith('/app/')).every(x=>x.auth==='Bearer TEST_ONLY'),'Auth header missing');
  assert.ok(!JSON.stringify(r).includes('PRIVATE_COOKIE')&&!JSON.stringify(r).includes('TEST_ONLY'),'Secret retained in results');
  console.log('PASS: real browser DOM crawler, executed-XSS detection, escaped-XSS negative case, form checks, JS errors, scope/exclusions, POST blocking and credential omission.');
}finally{server.closeAllConnections();server.close();}
