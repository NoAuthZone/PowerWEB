# SPDX-License-Identifier: MIT
# Lokaler, kontrollierter Smoke-Test fuer die Intruder-Engine. Kein externes Ziel.
# Startet einen Loopback-Testserver, der den Query-Wert reflektiert, und prueft
# Anfragezahl je Angriffsmodus, Reflexionserkennung, Limit, Scope/Ausschluss und
# die Freigabe fuer aendernde Methoden.
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'PowerWEB.Scanner.psm1') -Force
Import-Module (Join-Path $root 'PowerWEB.Audit.psm1') -Force
function Assert($Condition,$Message){ if(-not $Condition){ throw "FAIL: $Message" } }
$S=[char]0x00A7   # Positionsmarke (Paragraphzeichen)

$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $listener.Start(); $port=$listener.LocalEndpoint.Port
$scope="http://127.0.0.1:$port/app/"
$fixture=[hashtable]::Synchronized(@{Stop=$false;Count=0})
$server=[PowerShell]::Create()
[void]$server.AddScript({param($listener,$fixture)
    while(-not $fixture.Stop){
        if(-not $listener.Pending()){Start-Sleep -Milliseconds 5;continue}
        $client=$listener.AcceptTcpClient()
        try{
            $stream=$client.GetStream();$stream.ReadTimeout=3000;$reader=[IO.StreamReader]::new($stream)
            $line=$reader.ReadLine();if(-not $line){continue};$parts=$line.Split(' ');$uri=[Uri]('http://localhost'+$parts[1]);$headers=@{}
            while($line=$reader.ReadLine()){$pair=$line -split ':',2;$headers[$pair[0]]=$pair[1].Trim()}
            if($headers['Content-Length']){for($i=0;$i -lt [int]$headers['Content-Length'];$i++){[void]$reader.Read()}}
            $fixture.Count++
            $query=@{};foreach($part in $uri.Query.TrimStart('?').Split('&')){if($part){$p=$part -split '=',2;$query[[Uri]::UnescapeDataString($p[0])]=if($p.Count -gt 1){[Uri]::UnescapeDataString($p[1])}else{''}}}
            $body='ECHO '+($query.q)+' '+($query.id)
            $bytes=[Text.Encoding]::UTF8.GetBytes($body)
            $head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n")
            $stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length)
        }catch{}finally{$client.Close()}
    }
}).AddArgument($listener).AddArgument($fixture)
$handle=$server.BeginInvoke()
try{
    # 1) Sniper, eine Position, zwei Payloads -> zwei Anfragen, beide reflektiert.
    $r=Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}base${S}") -Mode 'Sniper' -PayloadSets @(,@('AAA','BBB')) -DelayMs 0
    Assert ($r.Rows.Count -eq 2) ('Sniper Anzahl: '+($r|ConvertTo-Json -Depth 6))
    Assert (@($r.Rows | Where-Object {$_.Reflected}).Count -eq 2) 'Sniper Reflexion'
    Assert ($r.Rows[0].Position -eq '1') 'Sniper Position 1-basiert'

    # 2) Cluster bomb, zwei Positionen, 2x2 -> vier Anfragen.
    $r=Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}x${S}&id=${S}y${S}") -Mode 'ClusterBomb' -PayloadSets @(@('a','b'),@('1','2')) -DelayMs 0
    Assert ($r.Rows.Count -eq 4) ('ClusterBomb Anzahl: '+$r.Rows.Count)
    Assert ($r.Rows[0].Position -eq '1,2') 'ClusterBomb zwei Positionen'

    # 3) Pitchfork, Sets 2 und 3 -> min = 2 Anfragen.
    $r=Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}x${S}&id=${S}y${S}") -Mode 'Pitchfork' -PayloadSets @(@('a','b'),@('1','2','3')) -DelayMs 0
    Assert ($r.Rows.Count -eq 2) ('Pitchfork Anzahl: '+$r.Rows.Count)

    # 4) MaxRequests begrenzt die Anfragen und meldet Limit.
    $r=Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}base${S}") -Mode 'Sniper' -PayloadSets @(,@('1','2','3','4','5','6','7','8','9','10')) -MaxRequests 3 -DelayMs 0
    Assert ($r.Rows.Count -eq 3 -and $r.Summary.Limitiert) 'MaxRequests-Limit'

    # 5) Ausschluss (logout) -> ausserhalb Zielbereich, keine echte Anfrage.
    $before=$fixture.Count
    $r=Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}base${S}") -Mode 'Sniper' -PayloadSets @(,@('logout')) -Exclude @('logout') -EncodeUrl:$false -DelayMs 0
    Assert ($r.Rows.Count -eq 1 -and $r.Rows[0].Error -match 'Outside' -and $fixture.Count -eq $before) 'Ausschluss/Scope'

    # 6) Aendernde Methode ohne Freigabe -> Ausnahme.
    $threw=$false
    try{ Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+"reflect?q=${S}b${S}") -Method 'POST' -Mode 'Sniper' -PayloadSets @(,@('x')) -DelayMs 0 }catch{ $threw=$true }
    Assert $threw 'POST ohne Freigabe muss abgelehnt werden'

    # 7) Keine Position markiert -> Ausnahme.
    $threw=$false
    try{ Invoke-PWIntruder -ScopeUrl $scope -UrlTemplate ($scope+'reflect?q=1') -Mode 'Sniper' -PayloadSets @(,@('x')) -DelayMs 0 }catch{ $threw=$true }
    Assert $threw 'Fehlende Position muss abgelehnt werden'

    Write-Host 'PASS: Test-Intruder' -ForegroundColor Green
}finally{
    $fixture.Stop=$true; $listener.Stop(); if(-not $handle.IsCompleted){$server.Stop()}; $server.Dispose()
}
