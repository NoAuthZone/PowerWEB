// SPDX-License-Identifier: MIT
import assert from 'node:assert/strict';
import {inScope} from '../browser/powerweb-browser.mjs';
const scope='https://example.org/app/';
for(const url of ['https://example.org/app/','https://example.org/app/a?q=1','https://example.org:443/app'])assert.equal(inScope(url,scope),true,url);
for(const url of ['http://example.org/app/','https://example.org:8443/app/','https://example.org.attacker.invalid/app/','https://example.org/application/','https://example.org/app/../outside','https://example.org/app/%2foutside','https://example.org/app/%252e%252e/','https://u:p@example.org/app/','javascript:alert(1)','data:text/html,test'])assert.equal(inScope(url,scope),false,url);
assert.equal(inScope('https://example.org/app/log%6fut',scope,['logout']),false);
assert.equal(inScope('https://example.org/app/search?q=%E0%A4',scope),false);
console.log('PASS: browser scope origin/port/path boundaries, encoded paths, excluded paths, URL credentials and unsupported schemes.');
