# SPDX-License-Identifier: MIT
# Local functional test for the table-driven request runner. Uses a loopback
# origin only. Checks table parsing, $var substitution (with boundary safety and
# URL encoding), reflection, scope/exclude gating and the request count.
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$mod=Import-Module (Join-Path $root 'PowerWEB.Scanner.psm1') -Force -PassThru
Import-Module (Join-Path $root 'PowerWEB.Audit.psm1') -Force
function Assert($c,$m){ if(-not $c){ throw "FAIL: $m" } }

$t=ConvertFrom-PWTableText "a,b`n1,x`n2,y`n3,z"
Assert ($t.Columns.Count -eq 2 -and $t.Rows.Count -eq 3) 'table parse count'
$u=& $mod { param($tp,$mp,$o,$e) Expand-PWVars $tp $mp $o $e } 'http://h/s?a=$a&b=$b' @{a='1';b='hi there'} @('a','b') $true
Assert ($u -eq 'http://h/s?a=1&b=hi%20there') "expand+encode: $u"
$u2=& $mod { param($tp,$mp,$o,$e) Expand-PWVars $tp $mp $o $e } 'p=$a1&q=$a' @{a='X';a1='Y'} @('a1','a') $false
Assert ($u2 -eq 'p=Y&q=X') "boundary safety: $u2"

$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$listener.Start();$port=$listener.LocalEndpoint.Port
$srv=[PowerShell]::Create()
[void]$srv.AddScript({param($l) while($true){ if(-not $l.Pending()){Start-Sleep -Milliseconds 5;continue}; $c=$l.AcceptTcpClient(); try{ $s=$c.GetStream();$s.ReadTimeout=3000;$sr=[IO.StreamReader]::new($s); $req=$sr.ReadLine(); while(($x=$sr.ReadLine())){}; $b=[Text.Encoding]::UTF8.GetBytes("ECHO "+$req); $h=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/html`r`nContent-Length: $($b.Length)`r`nConnection: close`r`n`r`n"); $s.Write($h,0,$h.Length);$s.Write($b,0,$b.Length) }catch{}finally{$c.Close()} }}).AddArgument($listener)
[void]$srv.BeginInvoke()
$scope="http://127.0.0.1:$port/"
$table="q,id`nalpha,1`nbeta,2`nlogout,3"
$r=Invoke-PWDataTable -ScopeUrl $scope -UrlTemplate ($scope+'search?q=$q&id=$id') -TableText $table -Exclude @('logout') -DelayMs 0
Assert ($r.Rows.Count -eq 3) "row count $($r.Rows.Count)"
Assert ($r.Rows[0].HTTP -eq 200 -and $r.Rows[0].Reflected) 'row 1 reflected'
Assert ($r.Rows[0].'#' -eq 1 -and $r.Rows[0].q -eq 'alpha') 'row 1 columns'
Assert ($r.Rows[2].Error -match 'Outside scope') 'excluded row'
Assert ($r.Summary.Anfragen -eq 2) "sent count $($r.Summary.Anfragen)"
Write-Host 'PASS: Test-DataTable' -ForegroundColor Green
$listener.Stop();$srv.Dispose()
