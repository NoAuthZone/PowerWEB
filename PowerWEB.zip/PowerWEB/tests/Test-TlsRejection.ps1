﻿# SPDX-License-Identifier: MIT
# Test default certificate validation against an untrusted local TLS endpoint.
$ErrorActionPreference='Stop'
Import-Module (Join-Path (Split-Path $PSScriptRoot -Parent) 'PowerWEB.Audit.psm1') -Force
$rsa=[Security.Cryptography.RSA]::Create(2048)
$request=[Security.Cryptography.X509Certificates.CertificateRequest]::new('CN=localhost',$rsa,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)
$temporary=$request.CreateSelfSigned([DateTimeOffset]::UtcNow.AddMinutes(-1),[DateTimeOffset]::UtcNow.AddDays(1))
$cert=[Security.Cryptography.X509Certificates.X509Certificate2]::new($temporary.Export([Security.Cryptography.X509Certificates.X509ContentType]::Pfx,'test'),'test',[Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $listener.Start(); $port=$listener.LocalEndpoint.Port
$server=[PowerShell]::Create()
[void]$server.AddScript({param($listener,$cert)
    $client=$listener.AcceptTcpClient(); $client.ReceiveTimeout=5000; $client.SendTimeout=5000
    $stream=[Net.Security.SslStream]::new($client.GetStream(),$false)
    try { $stream.AuthenticateAsServer($cert,$false,[Security.Authentication.SslProtocols]::Tls12,$false); 'Handshake completed' }
    catch { 'Handshake rejected by client: '+$_.Exception.Message }
    finally { $stream.Dispose(); $client.Close() }
}).AddArgument($listener).AddArgument($cert)
$handle=$server.BeginInvoke()
try {
    $rejected=$false
    try { $null=Invoke-PWHttp -Url "https://127.0.0.1:$port/" -ScopeUrl "https://127.0.0.1:$port/" -TimeoutSeconds 5 }
    catch {
        $errorText=$_.Exception.ToString()
        $rejected=$errorText -match 'TrustFailure|trust|Vertrauen|certificate|Zertifikat'
        if (-not $rejected) { throw "Unexpected TLS failure: $errorText" }
    }
    if (-not $rejected) { throw 'Untrusted TLS certificate was not rejected.' }
    if (-not $handle.AsyncWaitHandle.WaitOne(6000)) { throw 'TLS fixture did not complete.' }
    [void]$server.EndInvoke($handle)
    if ($server.HadErrors) { throw $server.Streams.Error[0] }
    'PASS: untrusted local TLS certificate rejected; no trust-store modification.'
} finally { $listener.Stop(); $server.Dispose(); $cert.Dispose(); $temporary.Dispose(); $rsa.Dispose() }
