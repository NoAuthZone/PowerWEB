﻿# SPDX-License-Identifier: MIT
# Local-only integration tests, no external service or additional test package.
[CmdletBinding()]
param([string]$ArtifactDirectory=$env:TEMP)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'PowerWEB.Audit.psm1') -Force
function Assert($Condition,[string]$Message) { if (-not $Condition) { throw $Message } }
foreach ($file in Get-ChildItem $root -Recurse -File | Where-Object { $_.Extension -in '.ps1','.psm1' }) {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    Assert ($errors.Count -eq 0) ($errors | Out-String)
}
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $listener.Start()
$port=$listener.LocalEndpoint.Port; $scope="http://127.0.0.1:$port/app/"
$fixture=[hashtable]::Synchronized(@{ Stop=$false; Seen=[Collections.ArrayList]::Synchronized([Collections.ArrayList]::new()) })
$server=[PowerShell]::Create()
[void]$server.AddScript({param($listener,$fixture,$port)
    while (-not $fixture.Stop) {
        if (-not $listener.Pending()) { Start-Sleep -Milliseconds 10; continue }
        $client=$listener.AcceptTcpClient()
        try {
            $stream=$client.GetStream(); $stream.ReadTimeout=3000
            $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::UTF8)
            $first=$reader.ReadLine(); if (-not $first) { continue }
            $parts=$first.Split(' '); $method=$parts[0]; $path=$parts[1]; $headers=@{}
            while ($line=$reader.ReadLine()) { $pair=$line -split ':',2; $headers[$pair[0]]=$pair[1].Trim() }
            if ($headers['Expect'] -eq '100-continue') { $interim=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 100 Continue`r`n`r`n"); $stream.Write($interim,0,$interim.Length) }
            $requestBody=''
            if ($headers['Content-Length']) {
                $n=[int]$headers['Content-Length']; $chars=New-Object char[] $n
                for ($i=0; $i -lt $n; $i++) { $chars[$i]=[char]$reader.Read() }
                $requestBody=-join $chars
            }
            [void]$fixture.Seen.Add([pscustomobject]@{ Method=$method; Path=$path; Authorization=$headers['Authorization']; Body=$requestBody })
            $body='<html><a href="/app/echo?q=hello">Echo</a><a href="/outside">Outside</a><a href="/app/logout">Logout</a><a href="/app/redirect">Redirect</a><a href="/app/echo?q=hello#part">Duplicate</a><a href="/app/missing">Missing</a></html>'
            $status='200 OK'; $extra=''
            if ($path -match '^/app/echo') { $body=[Uri]::UnescapeDataString($path)+' '+$requestBody }
            if ($path -eq '/app/large') { $body='x'*300000 }
            if ($path -eq '/app/slow') { Start-Sleep -Milliseconds 1200 }
            if ($path -eq '/app/redirect') { $status='302 Found'; $extra="Location: http://localhost:$port/outside`r`n" }
            if ($path -eq '/app/missing') { $status='404 Not Found'; $body='missing' }
            if ($headers['Origin']) { $extra+="Access-Control-Allow-Origin: $($headers['Origin'])`r`nAccess-Control-Allow-Credentials: true`r`n" }
            if ($method -eq 'OPTIONS') { $extra+="Allow: GET, POST, OPTIONS`r`n" }
            $bytes=[Text.Encoding]::UTF8.GetBytes($body)
            $head="HTTP/1.1 $status`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nSet-Cookie: session=PRIVATECOOKIE; Secure; HttpOnly; SameSite=Lax`r`nSet-Cookie: weak=HIDDEN; Path=/`r`n${extra}`r`n"
            $headBytes=[Text.Encoding]::ASCII.GetBytes($head); $stream.Write($headBytes,0,$headBytes.Length)
            if ($method -ne 'HEAD') { $stream.Write($bytes,0,$bytes.Length) }
        } catch { } finally { $client.Close() }
    }
}).AddArgument($listener).AddArgument($fixture).AddArgument($port)
$serverHandle=$server.BeginInvoke()
try {
    Assert (Test-PWScope "${scope}echo" $scope) 'Expected in-scope URL'
    foreach ($bad in @("http://127.0.0.1:$port/application/","http://localhost:$port/app/","https://127.0.0.1:$port/app/","http://127.0.0.1:$port/app/%2foutside",'file:///C:/Windows')) { Assert (-not (Test-PWScope $bad $scope)) "Scope escape accepted: $bad" }
    Assert (-not (Test-PWScope "${scope}logout" $scope @('logout'))) 'Exclusion failed'
    $blocked=$false; try { Invoke-PWHttp -Url "http://127.0.0.1:$port/outside" -ScopeUrl $scope } catch { $blocked=$true }; Assert $blocked 'Request escaped scope'
    $headers=ConvertFrom-PWHeaderText "Authorization: Bearer TESTTOKEN`nX-Test: sample"
    $r=Invoke-PWHttp -Url "${scope}echo?q=a" -ScopeUrl $scope -Headers $headers -Method POST -Body '{"sample":1}'
    Assert ($r.Status -eq 200 -and $r.Body.Contains('{"sample":1}')) 'POST body round trip failed'
    Assert ($fixture.Seen[$fixture.Seen.Count-1].Authorization -eq 'Bearer TESTTOKEN') 'Auth header not sent'
    $large=Invoke-PWHttp -Url "${scope}large" -ScopeUrl $scope -MaxBytes 1024
    Assert ($large.Truncated -and $large.Body.Length -eq 1024) 'Body limit failed'
    $scan=Invoke-PWAudit -ScopeUrl $scope -MaxPages 10 -MaxDepth 2 -DelayMs 0 -Active -Headers $headers
    Assert ($scan.Summary.Seiten -eq 4) ("Expected 4 discovered pages, got {0}" -f $scan.Summary.Seiten)
    Assert ($scan.Summary.Fehler -eq 0) ('Unexpected HTTP error: '+($scan.History | ConvertTo-Json))
    Assert (@($scan.History | Where-Object Status -eq 404).Count -gt 0) '404 not recorded'
    Assert (@($scan.Findings | Where-Object Titel -eq 'Test-Origin in CORS-Antwort uebernommen').Count -gt 0) 'CORS probe missing'
    Assert (@($scan.Findings | Where-Object Titel -eq 'Parameter wird im Inhalt reflektiert').Count -eq 1) 'Reflection probe failed'
    Assert (@($fixture.Seen | Where-Object { $_.Path -match '^/outside|logout' }).Count -eq 0) 'Crawler escaped scope/exclusion'
    $limited=Invoke-PWAudit -ScopeUrl $scope -MaxPages 1 -MaxDepth 2 -DelayMs 0
    Assert ($limited.History.Count -eq 1 -and $limited.Summary.RestQueue -gt 0) 'Page cap failed'
    $closed=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0); $closed.Start(); $closedPort=$closed.LocalEndpoint.Port; $closed.Stop()
    $failed=Invoke-PWAudit -ScopeUrl "http://127.0.0.1:$closedPort/" -MaxPages 1 -DelayMs 0 -TimeoutSeconds 1
    Assert ($failed.Summary.Status -eq 'Completed with errors' -and $failed.Summary.Fehler -eq 1) 'Connection failure incorrectly reported as clean scan'
    $fuzz=Invoke-PWFuzz -Template "${scope}echo?q={{PAYLOAD}}" -ScopeUrl $scope -Payloads @('alpha','a&b','<marker>') -DelayMs 0
    Assert ($fuzz.Rows.Count -eq 3 -and @($fuzz.Rows | Where-Object Reflektiert).Count -eq 3) 'Parameter test failed'
    $control=[hashtable]::Synchronized(@{ Cancel=$true; Request=$null; Message='' })
    $cancelled=Invoke-PWAudit -ScopeUrl $scope -Control $control -DelayMs 0
    Assert ($cancelled.Summary.Status -eq 'Cancelled' -and $cancelled.History.Count -eq 0) 'Pre-cancel failed'
    $midControl=[hashtable]::Synchronized(@{ Cancel=$false; Request=$null; Message='' })
    $midWorker=[PowerShell]::Create()
    [void]$midWorker.AddScript({param($module,$scope,$control) Import-Module $module; Invoke-PWAudit -ScopeUrl ($scope+'slow') -DelayMs 0 -Control $control }).AddArgument((Join-Path $root 'PowerWEB.Audit.psm1')).AddArgument($scope).AddArgument($midControl)
    try {
        $midHandle=$midWorker.BeginInvoke(); $until=[DateTime]::UtcNow.AddSeconds(5)
        while (-not $midControl.Request -and [DateTime]::UtcNow -lt $until) { Start-Sleep -Milliseconds 20 }
        Assert ($null -ne $midControl.Request) 'Cancellation test never started'
        $midControl.Cancel=$true; $midControl.Request.Abort()
        Assert ($midHandle.AsyncWaitHandle.WaitOne(5000)) 'Cancellation did not finish in 5 seconds'
        $midResult=$midWorker.EndInvoke($midHandle)
        Assert ($midResult[0].Summary.Status -eq 'Cancelled') 'Mid-request cancellation failed'
    } finally { $midWorker.Dispose() }
    $project=New-PWProject -Name '<script>alert(1)</script>' -ScopeUrl $scope
    $project.Findings=@($scan.Findings); $project.History=@($scan.History); $project.Runs=@($scan.Summary)
    $project.Checklist[0].Status='Geprueft'; $project.Checklist[0].Notizen='Local fixture'
    $jsonPath=Join-Path $ArtifactDirectory 'PowerWEB2-test.json'; $htmlPath=Join-Path $ArtifactDirectory 'PowerWEB2-test.html'; $csvPath=Join-Path $ArtifactDirectory 'PowerWEB2-test.csv'
    Save-PWProject $project $jsonPath
    $saved=Get-Content $jsonPath -Raw
    Assert ($saved -notmatch 'TESTTOKEN|PRIVATECOOKIE|HIDDEN') 'Secret leaked to project'
    $loaded=Import-PWProject $jsonPath
    Assert ($loaded.Findings.Count -eq $project.Findings.Count -and $loaded.Checklist[0].Status -eq 'Geprueft') 'Project round trip failed'
    Assert ($loaded.Settings.MaxPages -eq 20) 'Settings round trip failed'
    Export-PWProjectReport $project $htmlPath
    Assert ((Get-Content $htmlPath -Raw) -notmatch '<script>') 'HTML escaping failed'
    $project.Findings[0].Titel='=1+1'; Export-PWProjectReport $project $csvPath 'CSV'
    Assert ((Get-Content $csvPath -Raw).Contains("'=1+1")) 'CSV formula protection failed'
    'PASS: syntax, scope boundaries, exclusions, POST/auth, body cap, crawler/redirects/404, CORS/reflection, limits, parameter tests, cancellation, project round trip and report encoding.'

    . (Join-Path $root 'PowerWEB.Workbench.ps1') -NoShow
    function Click([string]$Name) { $controls[$Name].RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent)) }
    function Wait-UI {
        $until=[DateTime]::UtcNow.AddSeconds(20)
        while ($state.Worker -and [DateTime]::UtcNow -lt $until) { $window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background); Start-Sleep -Milliseconds 25 }
        Assert ($null -eq $state.Worker) 'GUI worker timeout'
        Assert (-not $controls.Status.Text.StartsWith('Fehler:')) $controls.Status.Text
    }
    $controls.Scope.Text=$scope; $controls.Delay.Text='0'; $controls.MaxPages.Text='3'; Click 'Start'; Wait-UI
    Assert ($state.Project.History.Count -eq 3 -and $controls.Findings.Items.Count -gt 0) 'GUI scan did not populate results'
    $controls.RequestUrl.Text="${scope}echo?q=gui"; Click 'Send'; Wait-UI
    Assert ($controls.Response.Text.Contains('gui')) 'GUI request failed'
    Click 'Baseline'; $controls.RequestUrl.Text="${scope}echo?q=changed"; Click 'Send'; Wait-UI; Click 'Compare'
    Assert ($controls.Status.Text.Contains('Inhalt identisch: False')) 'Response comparison failed'
    $controls.FuzzUrl.Text="${scope}echo?q={{PAYLOAD}}"; $controls.Payloads.Text="one`ntwo"; Click 'Fuzz'; Wait-UI
    Assert ($controls.FuzzResults.Items.Count -eq 2) 'GUI parameter test failed'
    Click 'NewFinding'; $controls.FindingTitle.Text='Manual test'; $controls.Evidence.Text='Repro'; Click 'ApplyFinding'
    Assert (@($state.Project.Findings | Where-Object Titel -eq 'Manual test').Count -eq 1) 'Manual finding failed'
    $controls.Filter.Text='Manual test'; Assert ($controls.Findings.Items.Count -eq 1) 'Finding filter failed'; $controls.Filter.Text=''
    $controls.Method.SelectedItem='POST'; $controls.AllowWrite.IsChecked=$false; Click 'Send'
    Assert ($null -eq $state.Worker -and $controls.Status.Text -match 'freigeben') 'Write-method gate failed'
    $controls.Method.SelectedItem='GET'
    $controls.Tabs.SelectedIndex=1; $window.Show(); $window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::ApplicationIdle); $window.UpdateLayout()
    $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new([int]$window.ActualWidth,[int]$window.ActualHeight,96,96,[Windows.Media.PixelFormats]::Pbgra32); $bitmap.Render($window)
    $encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new(); $encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
    $file=[IO.File]::Create((Join-Path $ArtifactDirectory 'PowerWEB2-preview.png')); try { $encoder.Save($file) } finally { $file.Dispose() }
    $state.Dirty=$false; $window.Close()
    'PASS: GUI start/scan/results, request editor, comparison, parameter tests, manual finding, filter and WPF rendering.'
} finally {
    $fixture.Stop=$true; $listener.Stop()
    if ($serverHandle.IsCompleted) { [void]$server.EndInvoke($serverHandle) } else { $server.Stop() }
    $server.Dispose()
}
