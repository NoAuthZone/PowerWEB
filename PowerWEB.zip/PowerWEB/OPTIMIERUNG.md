# PowerWEB 3.2: Optimierungen (verhaltenserhaltend)

Diese Änderungen verbessern Laufzeit und Codeklarheit, **ohne die Detektions-
oder Sicherheitslogik zu verändern**. Scan-Ergebnisse, Befunde, Redaction,
Scope-Prüfung und Berichte bleiben unverändert. Es wurden keine Regeln,
Schwellenwerte oder Ausgaben angefasst. Version bleibt 3.2.0.

## 1. `Merge-Findings` von O(n²) auf O(n) (PowerWEB.Workbench.ps1)

**Vorher:** Für jeden neuen Befund ein voller `Where-Object`-Scan über alle
bestehenden Befunde plus `@(...)+@($f)` — ein kompletter Array-Neuaufbau je
Einfügung. Bei `M` neuen und `N` bestehenden Befunden: ~`O((N+M)·M)` plus
`M` Array-Kopien. Wird nach jedem Scan-, Fuzz-, Browser- und Engine-Lauf
aufgerufen und wächst mit der Projektgröße.

**Nachher:** Einmaliger Aufbau eines `HashSet`-Schlüsselsatzes aus den
bestehenden Befunden, `O(1)`-Prüfung je neuem Befund, ein einziger
Array-Anbau am Ende. Ergebnis: `O(N+M)`.

**Semantik erhalten:** Der Schlüssel bildet die ursprüngliche Vergleichsregel
exakt ab — Titel case-insensitiv (`-eq`), URL und Nachweis case-sensitiv
(`-ceq`), getrennt durch ein `NUL`-Trennzeichen zur Kollisionsvermeidung.
Auch die Deduplizierung innerhalb desselben Batches bleibt identisch.

## 2. SHA-256-Instanz wiederverwenden (PowerWEB.Scanner.psm1)

**Vorher:** `Get-PWBodyDigest` erzeugte und verwarf pro Aufruf ein neues
`SHA256`-Objekt. Die Funktion wird im booleschen SQL-Test (`PW-SQL-BOOL`)
mehrfach je Seite/Parameter aufgerufen (Basis, Wiederholung, vier
True/False-Antworten) sowie im Rollenvergleich.

**Nachher:** Eine modulweite Instanz (`$script:PWSha256`), die je Aufruf
wiederverwendet wird. `ComputeHash` setzt seinen Zustand selbst zurück; Scans
laufen pro Runspace einzeln (kein Nebenläufigkeitsproblem). Identische
Hash-Ausgabe, weniger Allokationen.

## 3. Selected-Index-Liste vorberechnen (PowerWEB.Scanner.psm1)

In der Parameterschleife wurde `@($selected|ForEach-Object Index)` für **jeden**
Query-Parameter neu erzeugt, nur um „übersprungen"-Einträge zu protokollieren.
Jetzt einmal vor der Schleife berechnet. Gleiches Ergebnis.

## 4. `$matches`-Shadowing entfernt (PowerWEB.Audit.psm1)

In `Get-PWLinks` überschrieb `$matches=[regex]::Matches(...)` die automatische
PowerShell-Variable `$Matches` (die von `-match` befüllt wird). Umbenannt in
`$linkMatches` — beseitigt eine latente Verwechslungsquelle, kein
Verhaltensunterschied.

## Nicht angefasst (bewusst)

- Detektionsregeln, Risikobewertung, Schwellenwerte, Payload-Marker.
- Redaction (`Protect-PWText`/`Protect-PWUrl`), Scope-Prüfung, Truncation-Logik.
- Speicherformat (`SchemaVersion=2`), Report-Struktur, öffentliche Funktions-
  signaturen und Exporte.

## Prüfung

- Keine der bestehenden Tests referenziert die geänderten Funktionen direkt.
- Änderungen sind lokal und signatur-kompatibel; die vorhandenen Testskripte
  unter `tests/` sollten unverändert durchlaufen. Empfohlen vor Weitergabe auf
  einem Windows-Rechner mit PowerShell 5.1:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File .\tests\Test-PowerWEB2.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File .\tests\Test-NativeScanner.ps1
```
